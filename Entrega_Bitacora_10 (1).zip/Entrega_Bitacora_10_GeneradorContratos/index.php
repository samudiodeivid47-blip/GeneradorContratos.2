<?php
require_once __DIR__ . "/config/conexionBDD.php";


$datosEmpresa    = $_SESSION["datosEmpresa"]    ?? [];
$datosTrabajador = $_SESSION["datosTrabajador"] ?? [];
$datosContrato   = $_SESSION["datosContrato"]   ?? [];
$todosLosErrores = $_SESSION["errores"]         ?? [];
$mensaje         = $_SESSION["mensaje"]         ?? "";

unset($_SESSION["datosEmpresa"], $_SESSION["datosTrabajador"], $_SESSION["datosContrato"], $_SESSION["errores"], $_SESSION["mensaje"]);

require __DIR__ . "/vistas/formulario.php";
?>
