

CREATE DATABASE IF NOT EXISTS contratos_obra_labor
    CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;

USE contratos_obra_labor;


CREATE TABLE IF NOT EXISTS empresa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_empleador ENUM('natural','juridica') NOT NULL,
    razon_social VARCHAR(150) NOT NULL,
    nit VARCHAR(20) NOT NULL,
    representante_legal VARCHAR(150) NULL,
    documento_representante VARCHAR(20) NULL,
    direccion VARCHAR(50) NOT NULL,
    ciudad VARCHAR(80) NOT NULL,
    departamento VARCHAR(80) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    correo VARCHAR(80) NOT NULL,
    actividad_economica VARCHAR(150) NOT NULL,
    arl VARCHAR(80) NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_empresa_nit (nit)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS trabajador (
    id INT(50) AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(50) NOT NULL,
    tipo_documento ENUM('CC','CE','PPT','PEP','PASAPORTE') NOT NULL,
    numero_documento VARCHAR(20) NOT NULL,
    fecha_nacimiento DATE NULL,
    direccion VARCHAR(50) NOT NULL,
    ciudad VARCHAR(80) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    correo VARCHAR(80) NOT NULL,
    eps VARCHAR(100) NULL,
    fondo_pension VARCHAR(100) NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_trabajador_doc (tipo_documento, numero_documento)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS contrato (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT(50) NOT NULL,
    trabajador_id INT (50)NOT NULL,

    
    descripcion_obra TEXT NOT NULL,
    cargo VARCHAR(120) NOT NULL,
    funciones TEXT NOT NULL,
    lugar_ejecucion VARCHAR(200) NOT NULL,

    
    salario DECIMAL(12,2) NOT NULL,
    auxilio_transporte DECIMAL(12,2) NOT NULL DEFAULT 0,
    periodicidad_pago ENUM('semanal','quincenal','mensual') NOT NULL,
    forma_pago ENUM('consignacion','efectivo','transferencia') NOT NULL,

   
    jornada ENUM('completa','parcial') NOT NULL,
    horas_semanales DECIMAL(4,2) NOT NULL,
    horario VARCHAR(200) NULL,

  
    fecha_inicio DATE NOT NULL,
    condicion_terminacion TEXT NOT NULL,
    tiene_periodo_prueba TINYINT(1) NOT NULL DEFAULT 0,
    duracion_periodo_prueba_dias INT NULL,

   
    beneficios_extralegales TEXT NULL,
    observaciones TEXT NULL,

    
    estado ENUM('borrador','generado','anulado') NOT NULL DEFAULT 'borrador',
    fecha_generacion DATETIME NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_contrato_empresa
        FOREIGN KEY (empresa_id) REFERENCES empresa(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT fk_contrato_trabajador
        FOREIGN KEY (trabajador_id) REFERENCES trabajador(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS parametros_legales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    anio INT NOT NULL,
    salario_minimo_mensual DECIMAL(12,2) NOT NULL,
    auxilio_transporte_mensual DECIMAL(12,2) NOT NULL,
    fecha_actualizacion DATE NOT NULL,
    fuente VARCHAR(255) NOT NULL,
    UNIQUE KEY uq_parametros_anio (anio)
) ENGINE=InnoDB;


INSERT INTO parametros_legales (anio, salario_minimo_mensual, auxilio_transporte_mensual, fecha_actualizacion, fuente)
VALUES (2026, 1750905.00, 249095.00, '2026-02-19', 'Decreto 1469 de 2025 / Decreto 1470 de 2025 / Decreto 0159 de 2026 - Presidencia de la Republica')
ON DUPLICATE KEY UPDATE
    salario_minimo_mensual = VALUES(salario_minimo_mensual),
    auxilio_transporte_mensual = VALUES(auxilio_transporte_mensual),
    fecha_actualizacion = VALUES(fecha_actualizacion),
    fuente = VALUES(fuente);
