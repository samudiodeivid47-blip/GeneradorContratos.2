-- Solo si ya habías importado la BD de las bitácoras 8 o 9:
-- los teléfonos celulares (ej. 3001234567) no caben en INT y el documento puede tener hasta 20 caracteres.
USE contratos_obra_labor;
ALTER TABLE empresa    MODIFY telefono VARCHAR(15) NOT NULL;
ALTER TABLE trabajador MODIFY telefono VARCHAR(15) NOT NULL;
ALTER TABLE trabajador MODIFY numero_documento VARCHAR(20) NOT NULL;
