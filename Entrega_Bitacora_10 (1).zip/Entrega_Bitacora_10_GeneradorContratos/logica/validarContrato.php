<?php
/**
 * Valida los datos del contrato (obra o labor determinada) contra los parámetros legales.
 */
function validarContrato($datos, $parametrosLegales)
{
    $errores = [];

    
    $descripcion = trim($datos["descripcion_obra"] ?? "");
    if (empty($descripcion)) {
        $errores["descripcion_obra"] = "La descripción de la obra o labor es obligatoria.";
    } elseif (mb_strlen($descripcion) < 40) {
        $errores["descripcion_obra"] = "La descripción parece demasiado breve o genérica. La ley exige que la obra o labor se describa de forma precisa y detallada.";
    }

    if (empty(trim($datos["cargo"] ?? ""))) {
        $errores["cargo"] = "El cargo es obligatorio.";
    }

    $funciones = trim($datos["funciones"] ?? "");
    if (empty($funciones)) {
        $errores["funciones"] = "Las funciones del trabajador son obligatorias.";
    } elseif (mb_strlen($funciones) < 20) {
        $errores["funciones"] = "Describa las funciones con mayor detalle.";
    }

    if (empty(trim($datos["lugar_ejecucion"] ?? ""))) {
        $errores["lugar_ejecucion"] = "El lugar de ejecución es obligatorio.";
    }

    
    $salario = filter_var($datos["salario"] ?? null, FILTER_VALIDATE_FLOAT);
    $salarioMinimo = (float) $parametrosLegales["salario_minimo_mensual"];

    if ($salario === false || $salario <= 0) {
        $errores["salario"] = "El salario debe ser un número mayor que cero.";
    } elseif ($salario < $salarioMinimo) {
        $errores["salario"] = "El salario ingresado (\$" . number_format($salario, 0, ",", ".") .
            ") es inferior al salario mínimo legal mensual vigente para " . $parametrosLegales["anio"] .
            " (\$" . number_format($salarioMinimo, 0, ",", ".") . "). " .
            "Esto solo es válido si el contrato es de tiempo parcial y el salario se calcula proporcionalmente; verifique este caso.";
    }

    
    $horas = filter_var($datos["horas_semanales"] ?? null, FILTER_VALIDATE_FLOAT);
    if ($horas === false || $horas <= 0) {
        $errores["horas_semanales"] = "Las horas semanales deben ser un número mayor que cero.";
    } elseif ($horas > JORNADA_MAXIMA_SEMANAL) {
        $errores["horas_semanales"] = "La jornada máxima legal vigente es de " . JORNADA_MAXIMA_SEMANAL .
            " horas semanales (Ley 2101 de 2021, reducción gradual). Verifique el cronograma vigente si esta validación quedó desactualizada.";
    }

    if (($datos["jornada"] ?? "") === "parcial" && $horas >= JORNADA_MAXIMA_SEMANAL) {
        $errores["jornada"] = "Seleccionó jornada parcial pero las horas semanales son iguales o mayores a la jornada máxima legal. Revise la coherencia.";
    }

  
    $auxilio = filter_var($datos["auxilio_transporte"] ?? 0, FILTER_VALIDATE_FLOAT);
    $auxilioLegal = (float) $parametrosLegales["auxilio_transporte_mensual"];

    if ($salario !== false && $salario <= (2 * $salarioMinimo) && $auxilio == 0) {
        
    }


    $fechaInicio = DateTime::createFromFormat("Y-m-d", $datos["fecha_inicio"] ?? "");
    if (!$fechaInicio) {
        $errores["fecha_inicio"] = "La fecha de inicio no es válida.";
    }

    if (empty(trim($datos["condicion_terminacion"] ?? ""))) {
        $errores["condicion_terminacion"] = "Debe describirse la condición o hito que determina la finalización de la obra o labor.";
    }

  
    if (!empty($datos["tiene_periodo_prueba"]) && $datos["tiene_periodo_prueba"] == 1) {
        $dias = filter_var($datos["duracion_periodo_prueba_dias"] ?? null, FILTER_VALIDATE_INT);
        if ($dias === false || $dias <= 0) {
            $errores["duracion_periodo_prueba_dias"] = "Debe indicar la duración del período de prueba en días.";
        }
    }

    return $errores;
}


function construirRevisionLegal($datos, $errores, $parametrosLegales)
{
    $revision = [
        "completos" => [],
        "advertencias" => [],
        "bloqueantes" => [],
    ];

    
    foreach ($errores as $campo => $mensaje) {
        $revision["bloqueantes"][] = $mensaje;
    }

   
    if (!isset($errores["descripcion_obra"])) {
        $revision["completos"][] = "Descripción de la obra o labor: cumple el mínimo de detalle exigido operativamente.";
    }
    if (!isset($errores["salario"])) {
        $revision["completos"][] = "Salario: igual o superior al mínimo legal vigente.";
    }
    if (!isset($errores["horas_semanales"])) {
        $revision["completos"][] = "Jornada: dentro del máximo legal vigente.";
    }

  
    $salario = filter_var($datos["salario"] ?? null, FILTER_VALIDATE_FLOAT);
    $auxilio = filter_var($datos["auxilio_transporte"] ?? 0, FILTER_VALIDATE_FLOAT);
    $salarioMinimo = (float) $parametrosLegales["salario_minimo_mensual"];

    if ($salario !== false && $salario <= (2 * $salarioMinimo) && $auxilio == 0) {
        $revision["advertencias"][] = "El trabajador devenga hasta 2 salarios mínimos y no se asignó auxilio de transporte. Verifique si le corresponde por ley (salvo que la empresa suministre transporte).";
    }

    if (!empty($datos["tiene_periodo_prueba"]) && $datos["tiene_periodo_prueba"] == 1) {
        $revision["advertencias"][] = "Se incluyó período de prueba. Verifique que su duración no exceda los límites legales ni la duración estimada de la obra.";
    }

    if (empty(trim($datos["beneficios_extralegales"] ?? ""))) {
        $revision["advertencias"][] = "No se registraron beneficios extralegales (opcional, solo si aplica).";
    }

    $revision["advertencias"][] = "Este sistema no verifica automáticamente la clasificación de riesgo laboral ante la ARL ni el dígito de verificación oficial del NIT ante la DIAN.";

    return $revision;
}
?>
