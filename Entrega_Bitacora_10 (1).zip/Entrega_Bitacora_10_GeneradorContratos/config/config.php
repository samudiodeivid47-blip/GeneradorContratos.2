<?php


define("SERVIDOR", "localhost");
define("USUARIO", "root");
define("PASSWORD", "");
define("BASE_DATOS", "contratos_obra_labor");


define("JORNADA_MAXIMA_SEMANAL", 42);


date_default_timezone_set("America/Bogota");


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
