<?php
/*
 * Portada pública: explica de qué se trata ContractPro. No consulta la base
 * de datos ni muestra datos de nadie. El trabajo se hace en panel.php.
 */
require_once __DIR__ . "/config/config.php";
require_once __DIR__ . "/logica/sesion.php";

$dentro = estaAutenticado();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ContractPro — Contratos por obra o labor, claros y revisados</title>
    <meta name="description" content="Genera, revisa y controla contratos de trabajo por obra o labor determinada para microempresas de Bogotá, con control de riesgo, calendario y protección de datos personales.">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="portada">

<header class="portada-barra">
    <a class="portada-marca" href="index.php">ContractPro</a>
    <nav class="portada-enlaces" aria-label="Secciones">
        <a href="#que-es">¿Qué es?</a>
        <a href="#funciones">Funciones</a>
        <a href="#como-funciona">Cómo funciona</a>
        <a href="#perfiles">Perfiles</a>
        <a href="#confianza">Seguridad y ley</a>
    </nav>
    <?php if ($dentro) { ?>
        <a class="btn-portada" href="panel.php">Ir al panel</a>
    <?php } else { ?>
        <a class="btn-portada" href="vistas/login.php">Ingresar</a>
    <?php } ?>
</header>

<main>
    <!-- ============ Portada ============ -->
    <section class="portada-hero">
        <div class="portada-hero-texto">
            <p class="portada-etiqueta">Para microempresas de Bogotá</p>
            <h1>Contratos por obra o labor, <span>claros, revisados y bajo control</span></h1>
            <p class="portada-lead">
                ContractPro ayuda a redactar el contrato por obra o labor determinada, a detectar a tiempo los riesgos
                laborales y de datos personales, y a que un supervisor lo revise antes de firmarlo.
            </p>
            <div class="portada-acciones">
                <?php if ($dentro) { ?>
                    <a class="btn-portada btn-portada-grande" href="panel.php">Ir al panel</a>
                    <a class="btn-portada-claro" href="vistas/contratoForm.php">Nuevo contrato</a>
                <?php } else { ?>
                    <a class="btn-portada btn-portada-grande" href="vistas/login.php">Ingresar</a>
                    <?php if (REGISTRO_PUBLICO) { ?><a class="btn-portada-claro" href="vistas/registro.php">Crear una cuenta</a><?php } ?>
                <?php } ?>
            </div>
        </div>
        <div class="portada-hero-imagen" aria-hidden="true">
            <svg viewBox="0 0 320 380" role="img" focusable="false">
                <rect x="40" y="20" width="240" height="330" rx="14" fill="#ffffff" stroke="#c9ced6" stroke-width="2"/>
                <rect x="64" y="52" width="130" height="14" rx="7" fill="#1a2c42"/>
                <rect x="64" y="84" width="190" height="8" rx="4" fill="#d7dbe0"/>
                <rect x="64" y="104" width="170" height="8" rx="4" fill="#d7dbe0"/>
                <rect x="64" y="124" width="185" height="8" rx="4" fill="#d7dbe0"/>
                <rect x="64" y="162" width="100" height="10" rx="5" fill="#2c4a6e"/>
                <rect x="64" y="186" width="190" height="8" rx="4" fill="#d7dbe0"/>
                <rect x="64" y="206" width="160" height="8" rx="4" fill="#d7dbe0"/>
                <rect x="64" y="256" width="86" height="1.5" fill="#212529"/>
                <rect x="174" y="256" width="86" height="1.5" fill="#212529"/>
                <circle cx="240" cy="316" r="38" fill="#1e7e34"/>
                <path d="M222 316 l13 13 l25 -27" fill="none" stroke="#ffffff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
                <rect x="20" y="108" width="96" height="30" rx="15" fill="#a9822f"/>
                <rect x="34" y="119" width="68" height="8" rx="4" fill="#ffffff"/>
            </svg>
        </div>
    </section>

    <!-- ============ Qué es ============ -->
    <section class="portada-seccion" id="que-es">
        <h2>¿De qué se trata?</h2>
        <div class="portada-dos">
            <div>
                <p>
                    El <strong>contrato por obra o labor determinada</strong> dura lo que dura la obra. Por eso debe
                    constar por escrito y describir la obra de forma precisa y detallada (Ley 2466 de 2025). Muchas
                    microempresas lo hacen con formatos copiados que dejan huecos: fechas sin definir, falta de ARL o
                    datos del trabajador guardados sin su autorización.
                </p>
                <p>
                    ContractPro guía el proceso completo: se registran el empleador y el trabajador, se redacta el
                    contrato, el sistema <strong>revisa los riesgos</strong> y un <strong>supervisor aprueba</strong>
                    antes de que el documento quede como versión definitiva.
                </p>
            </div>
            <ul class="portada-lista-chequeo">
                <li>Contrato listo para imprimir o guardar en PDF</li>
                <li>Riesgos detectados antes de firmar, no después</li>
                <li>Una persona distinta a la autora aprueba cada contrato</li>
                <li>Fechas clave en un calendario con festivos de Colombia</li>
                <li>Datos personales tratados conforme a la Ley 1581 de 2012</li>
            </ul>
        </div>
    </section>

    <!-- ============ Funciones ============ -->
    <section class="portada-seccion portada-seccion-gris" id="funciones">
        <h2>Lo que incluye</h2>
        <div class="portada-tarjetas">
            <article class="portada-tarjeta">
                <h3>Formularios separados</h3>
                <p>Empresas, trabajadores y contratos tienen cada uno su formulario para registrar, consultar y actualizar. También hay un asistente de 3 pasos.</p>
            </article>
            <article class="portada-tarjeta">
                <h3>Control de riesgo</h3>
                <p>15 factores revisados automáticamente (sin ARL, menor de edad, sin autorización de datos, descripción muy corta…) con nivel bajo, medio o alto y recomendación para cada uno.</p>
            </article>
            <article class="portada-tarjeta">
                <h3>Revisión del supervisor</h3>
                <p>Aprobar, rechazar o anular, con observaciones. No se aprueba un contrato con riesgos graves sin controlar, ni el propio.</p>
            </article>
            <article class="portada-tarjeta">
                <h3>Fechas y calendario</h3>
                <p>Firma, inicio, fin del período de prueba y terminación estimada, junto a los festivos de Colombia y las fechas legales. Se exporta a tu calendario (.ics).</p>
            </article>
            <article class="portada-tarjeta">
                <h3>Datos personales</h3>
                <p>Autorización del trabajador con fecha y medio, política de tratamiento, y solicitudes de consulta o reclamo con plazo en días hábiles.</p>
            </article>
            <article class="portada-tarjeta">
                <h3>Ley a la mano</h3>
                <p>Marco legal consultable dentro del sistema, con cada norma marcada como verificada o por verificar.</p>
            </article>
        </div>
    </section>

    <!-- ============ Cómo funciona ============ -->
    <section class="portada-seccion" id="como-funciona">
        <h2>Cómo funciona</h2>
        <ol class="portada-pasos">
            <li><strong>Registra</strong><span>la empresa y el trabajador, con la autorización de datos del trabajador.</span></li>
            <li><strong>Redacta</strong><span>el contrato: obra, funciones, salario, jornada y fechas.</span></li>
            <li><strong>Revisa el riesgo</strong><span>el sistema muestra qué falta o qué podría generar problemas.</span></li>
            <li><strong>Aprueba e imprime</strong><span>el supervisor decide; el contrato aprobado se imprime sin marca de borrador.</span></li>
        </ol>
    </section>

    <!-- ============ Perfiles ============ -->
    <section class="portada-seccion portada-seccion-gris" id="perfiles">
        <h2>Perfil de administrador</h2>
        <div class="portada-tarjetas">
            <article class="portada-tarjeta">
                <h3>Administrador de ContractPro</h3>
                <p>Gestiona las cuentas y los perfiles de acceso, supervisa la actividad del sistema y administra los registros de empresas, trabajadores, contratos, calendario, riesgos y solicitudes de datos personales según los permisos configurados.</p>
            </article>
        </div>
    </section>

    <!-- ============ Seguridad y ley ============ -->
    <section class="portada-seccion" id="confianza">
        <h2>Seguridad y respeto por los datos</h2>
        <div class="portada-dos">
            <ul class="portada-lista-chequeo">
                <li>Contraseñas cifradas y bloqueo tras intentos fallidos</li>
                <li>Cierre de sesión por inactividad</li>
                <li>Protección contra formularios falsificados (CSRF)</li>
                <li>Cada usuario solo accede a lo que le corresponde</li>
                <li>Bitácora de quién hizo qué y cuándo</li>
            </ul>
            <div class="portada-aviso">
                <h3>Una ayuda, no un abogado</h3>
                <p>
                    ContractPro apoya la elaboración y el control de contratos, pero <strong>no reemplaza la asesoría de
                    un abogado laboralista</strong>. Los textos marcados «[VERIFICAR]» y las normas «por verificar» deben
                    confirmarse en la fuente oficial antes de usarlos con datos reales.
                    <a href="vistas/politicaDatos.php">Leer la política de tratamiento de datos</a>.
                </p>
            </div>
        </div>
    </section>

    <!-- ============ Llamado final ============ -->
    <section class="portada-final">
        <h2>¿Listo para empezar?</h2>
        <p>Ingresa y genera tu primer contrato.</p>
        <?php if ($dentro) { ?>
            <a class="btn-portada btn-portada-grande" href="panel.php">Ir al panel</a>
        <?php } else { ?>
            <a class="btn-portada btn-portada-grande" href="vistas/login.php">Ingresar</a>
            <?php if (REGISTRO_PUBLICO) { ?><a class="btn-portada-claro btn-portada-claro-oscuro" href="vistas/registro.php">Crear una cuenta</a><?php } ?>
        <?php } ?>
    </section>
</main>

<footer class="portada-pie">
    <p>ContractPro · Contratos por obra o labor determinada · Bogotá, Colombia</p>
    <p><a href="vistas/politicaDatos.php">Política de tratamiento de datos</a></p>
</footer>
</body>
</html>
