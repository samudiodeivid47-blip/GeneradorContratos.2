<?php
/*
 * Departamentos de Colombia y sus ciudades principales para las listas
 * desplegables. No incluye los ~1.100 municipios: para los demás existe la
 * opción "Otra ciudad..." (se escribe el nombre a mano).
 * Bogotá D.C. se guarda como ciudad dentro de Cundinamarca.
 */
const CIUDAD_OTRA = "__otra__";

function departamentosColombia()
{
    return [
        "Amazonas" => ["Leticia", "Puerto Nariño"],
        "Antioquia" => ["Medellín", "Apartadó", "Bello", "Caucasia", "Envigado", "Itagüí", "Rionegro", "Sabaneta", "Turbo"],
        "Arauca" => ["Arauca", "Arauquita", "Saravena", "Tame"],
        "Atlántico" => ["Barranquilla", "Malambo", "Puerto Colombia", "Sabanalarga", "Soledad"],
        "Bolívar" => ["Cartagena", "El Carmen de Bolívar", "Magangué", "Turbaco"],
        "Boyacá" => ["Tunja", "Chiquinquirá", "Duitama", "Sogamoso"],
        "Caldas" => ["Manizales", "Chinchiná", "La Dorada", "Villamaría"],
        "Caquetá" => ["Florencia", "San Vicente del Caguán"],
        "Casanare" => ["Yopal", "Aguazul", "Villanueva"],
        "Cauca" => ["Popayán", "Puerto Tejada", "Santander de Quilichao"],
        "Cesar" => ["Valledupar", "Aguachica", "Bosconia"],
        "Chocó" => ["Quibdó", "Istmina"],
        "Córdoba" => ["Montería", "Cereté", "Lorica", "Sahagún"],
        "Cundinamarca" => ["Bogotá D.C.", "Cajicá", "Chía", "Facatativá", "Fusagasugá", "Funza", "Girardot", "Madrid", "Mosquera", "Soacha", "Zipaquirá"],
        "Guainía" => ["Inírida"],
        "Guaviare" => ["San José del Guaviare"],
        "Huila" => ["Neiva", "Garzón", "La Plata", "Pitalito"],
        "La Guajira" => ["Riohacha", "Maicao", "Uribia"],
        "Magdalena" => ["Santa Marta", "Ciénaga", "Fundación"],
        "Meta" => ["Villavicencio", "Acacías", "Granada"],
        "Nariño" => ["Pasto", "Ipiales", "Tumaco"],
        "Norte de Santander" => ["Cúcuta", "Ocaña", "Pamplona", "Villa del Rosario"],
        "Putumayo" => ["Mocoa", "Puerto Asís"],
        "Quindío" => ["Armenia", "Calarcá", "Montenegro"],
        "Risaralda" => ["Pereira", "Dosquebradas", "Santa Rosa de Cabal"],
        "San Andrés y Providencia" => ["San Andrés"],
        "Santander" => ["Bucaramanga", "Barrancabermeja", "Floridablanca", "Girón", "Piedecuesta", "San Gil"],
        "Sucre" => ["Sincelejo", "Corozal"],
        "Tolima" => ["Ibagué", "Espinal", "Honda"],
        "Valle del Cauca" => ["Cali", "Buenaventura", "Buga", "Cartago", "Jamundí", "Palmira", "Tuluá"],
        "Vaupés" => ["Mitú"],
        "Vichada" => ["Puerto Carreño"],
    ];
}
?>
