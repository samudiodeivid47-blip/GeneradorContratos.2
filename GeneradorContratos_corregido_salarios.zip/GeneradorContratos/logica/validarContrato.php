<?php
/*
 * Reglas de validación para las condiciones del contrato por obra o
 * labor determinada.
 *
 * IMPORTANTE: estas validaciones son un apoyo operativo, no un concepto
 * jurídico. Se basan en reglas generales del Código Sustantivo del
 * Trabajo y la Ley 2466 de 2025 conocidas al momento del desarrollo.
 * No sustituyen la revisión de un abogado laboralista para el caso
 * concreto.
 */
// Devuelve un DateTime si el texto es una fecha real en formato Y-m-d; si no, null.
function fechaValida($texto)
{
    $d = DateTime::createFromFormat("Y-m-d", (string) $texto);
    if (!$d || $d->format("Y-m-d") !== $texto) {
        return null;
    }
    $d->setTime(0, 0);
    return $d;
}

function validarContrato($datos, $parametrosLegales)
{
    $errores = [];

    // ---------- Descripción de la obra o labor ----------
    // La Ley 2466 de 2025 exige que la obra o labor se describa de forma
    // "precisa y detallada". Se aplica un mínimo de caracteres y de
    // palabras como filtro operativo contra descripciones genéricas;
    // esto NO garantiza que la descripción sea jurídicamente suficiente,
    // solo evita los casos evidentemente insuficientes.
    $descripcion = trim($datos["descripcion_obra"] ?? "");
    if (empty($descripcion)) {
        $errores["descripcion_obra"] = "La descripción de la obra o labor es obligatoria.";
    } elseif (mb_strlen($descripcion) < 40) {
        $errores["descripcion_obra"] = "La descripción parece demasiado breve o genérica. La ley exige que la obra o labor se describa de forma precisa y detallada.";
    }

    if (empty(trim($datos["cargo"] ?? ""))) {
        $errores["cargo"] = "El cargo es obligatorio.";
    }

    $funciones = trim($datos["funciones"] ?? "");
    if (empty($funciones)) {
        $errores["funciones"] = "Las funciones del trabajador son obligatorias.";
    } elseif (mb_strlen($funciones) < 20) {
        $errores["funciones"] = "Describa las funciones con mayor detalle.";
    }

    if (empty(trim($datos["lugar_ejecucion"] ?? ""))) {
        $errores["lugar_ejecucion"] = "El lugar de ejecución es obligatorio.";
    }

    // ---------- Salario ----------
    $salario = filter_var($datos["salario"] ?? null, FILTER_VALIDATE_FLOAT);
    $salarioMinimo = (float) $parametrosLegales["salario_minimo_mensual"];

    if ($salario === false || $salario <= 0) {
        $errores["salario"] = "El salario debe ser un número mayor que cero.";
    } elseif ($salario < $salarioMinimo) {
        $errores["salario"] = "El salario ingresado (\$" . number_format($salario, 0, ",", ".") .
            ") es inferior al salario mínimo legal mensual vigente para " . $parametrosLegales["anio"] .
            " (\$" . number_format($salarioMinimo, 0, ",", ".") . "). " .
            "Esto solo es válido si el contrato es de tiempo parcial y el salario se calcula proporcionalmente; verifique este caso.";
    }

    // ---------- Jornada ----------
    $horas = filter_var($datos["horas_semanales"] ?? null, FILTER_VALIDATE_FLOAT);
    if ($horas === false || $horas <= 0) {
        $errores["horas_semanales"] = "Las horas semanales deben ser un número mayor que cero.";
    } elseif ($horas > JORNADA_MAXIMA_SEMANAL) {
        $errores["horas_semanales"] = "La jornada máxima legal vigente es de " . JORNADA_MAXIMA_SEMANAL .
            " horas semanales (Ley 2101 de 2021, reducción gradual). Verifique el cronograma vigente si esta validación quedó desactualizada.";
    }

    if (($datos["jornada"] ?? "") === "parcial" && $horas >= JORNADA_MAXIMA_SEMANAL) {
        $errores["jornada"] = "Seleccionó jornada parcial pero las horas semanales son iguales o mayores a la jornada máxima legal. Revise la coherencia.";
    }

    // ---------- Auxilio de transporte ----------
    // El auxilio de transporte legalmente corresponde a quienes devengan
    // hasta dos (2) salarios mínimos y no tienen transporte suministrado
    // por el empleador. Se muestra como advertencia, no como bloqueo,
    // porque depende de condiciones que el sistema no puede verificar
    // por completo (p. ej. si la empresa ya suministra transporte).
    $auxilio = filter_var($datos["auxilio_transporte"] ?? 0, FILTER_VALIDATE_FLOAT);
    $auxilioLegal = (float) $parametrosLegales["auxilio_transporte_mensual"];

    if ($salario !== false && $salario <= (2 * $salarioMinimo) && $auxilio == 0) {
        // No es un error bloqueante: se reporta como advertencia en la revisión legal.
    }

    // ---------- Fechas ----------
    // Todas se validan como fecha real (Y-m-d). La fecha de firma es opcional
    // (si se deja vacía se usa la de hoy). La fecha estimada de terminación
    // es solo una referencia para el calendario: el contrato termina con la obra.
    $fechaInicio = fechaValida($datos["fecha_inicio"] ?? "");
    if (!$fechaInicio) {
        $errores["fecha_inicio"] = "La fecha de inicio no es válida.";
    } else {
        $hoy = new DateTime("today");
        if ($fechaInicio < (clone $hoy)->modify("-1 year")) {
            $errores["fecha_inicio"] = "La fecha de inicio es de hace más de un año. Verifique la fecha; un contrato firmado mucho después de iniciar labores debe revisarse con un abogado.";
        } elseif ($fechaInicio > (clone $hoy)->modify("+1 year")) {
            $errores["fecha_inicio"] = "La fecha de inicio está a más de un año. Verifique la fecha.";
        }
    }

    $fechaFirma = null;
    if (trim($datos["fecha_firma"] ?? "") !== "") {
        $fechaFirma = fechaValida($datos["fecha_firma"]);
        if (!$fechaFirma) {
            $errores["fecha_firma"] = "La fecha de firma no es válida.";
        } elseif ($fechaFirma > (new DateTime("today"))->modify("+1 year")) {
            $errores["fecha_firma"] = "La fecha de firma está a más de un año. Verifique la fecha.";
        }
    }

    $fechaFin = null;
    if (trim($datos["fecha_terminacion_estimada"] ?? "") !== "") {
        $fechaFin = fechaValida($datos["fecha_terminacion_estimada"]);
        if (!$fechaFin) {
            $errores["fecha_terminacion_estimada"] = "La fecha estimada de terminación no es válida.";
        } elseif ($fechaInicio && $fechaFin <= $fechaInicio) {
            $errores["fecha_terminacion_estimada"] = "La fecha estimada de terminación debe ser posterior a la fecha de inicio.";
        }
    }

    if (empty(trim($datos["condicion_terminacion"] ?? ""))) {
        $errores["condicion_terminacion"] = "Debe describirse la condición o hito que determina la finalización de la obra o labor.";
    }

    // ---------- Período de prueba ----------
    // El Código Sustantivo del Trabajo (art. 78) limita el período de prueba
    // a dos meses: aquí 60 días. Además no puede ser más largo que la obra
    // si se conoce una fecha estimada de terminación.
    if (!empty($datos["tiene_periodo_prueba"]) && $datos["tiene_periodo_prueba"] == 1) {
        $dias = filter_var($datos["duracion_periodo_prueba_dias"] ?? null, FILTER_VALIDATE_INT);
        if ($dias === false || $dias <= 0) {
            $errores["duracion_periodo_prueba_dias"] = "Debe indicar la duración del período de prueba en días.";
        } elseif ($dias > PERIODO_PRUEBA_MAX_DIAS) {
            $errores["duracion_periodo_prueba_dias"] = "El período de prueba no puede superar " . PERIODO_PRUEBA_MAX_DIAS . " días (dos meses, art. 78 del Código Sustantivo del Trabajo).";
        } elseif ($fechaInicio && $fechaFin) {
            $duracionObra = (int) $fechaInicio->diff($fechaFin)->days;
            if ($dias > $duracionObra) {
                $errores["duracion_periodo_prueba_dias"] = "El período de prueba no puede ser más largo que la duración estimada de la obra ($duracionObra días).";
            }
        }
    }

    return $errores;
}
?>
