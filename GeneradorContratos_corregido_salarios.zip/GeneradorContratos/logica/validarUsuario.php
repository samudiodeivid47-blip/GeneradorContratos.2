<?php
/*
 * Reglas de validación para usuarios (registro y perfil).
 * Retornan un arreglo campo => mensaje de error (vacío = sin errores).
 */

// Regla de contraseña segura: 10 a 72 caracteres, con mayúscula, minúscula y número.
// (bcrypt solo usa los primeros 72 bytes.)
function validarClaveSegura($clave, $nombreUsuario = "")
{
    if (strlen($clave) < 10) {
        return "La contraseña debe tener al menos 10 caracteres.";
    }
    if (strlen($clave) > 72) {
        return "La contraseña no puede superar 72 caracteres.";
    }
    if (!preg_match('/[a-z]/', $clave) || !preg_match('/[A-Z]/', $clave) || !preg_match('/[0-9]/', $clave)) {
        return "La contraseña debe combinar mayúsculas, minúsculas y números.";
    }
    if ($nombreUsuario !== "" && stripos($clave, $nombreUsuario) !== false) {
        return "La contraseña no debe contener su nombre de usuario.";
    }
    return null;
}

function validarRegistroUsuario($datos, $clave, $clave2, $aceptaPolitica)
{
    $errores = [];

    $nombre = trim($datos["nombre_completo"] ?? "");
    if (mb_strlen($nombre) < 3) {
        $errores["nombre_completo"] = "Escriba su nombre completo (mínimo 3 caracteres).";
    }

    $usuario = trim($datos["nombre_usuario"] ?? "");
    if (!preg_match('/^[A-Za-z0-9_]{4,30}$/', $usuario)) {
        $errores["nombre_usuario"] = "El usuario debe tener de 4 a 30 caracteres: solo letras, números y guion bajo.";
    }

    $correo = trim($datos["correo"] ?? "");
    if ($correo !== "" && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores["correo"] = "El correo electrónico no es válido.";
    }

    $errorClave = validarClaveSegura($clave, $usuario);
    if ($errorClave) {
        $errores["clave"] = $errorClave;
    }
    if ($clave !== $clave2) {
        $errores["clave2"] = "Las contraseñas no coinciden.";
    }

    if (!$aceptaPolitica) {
        $errores["politica"] = "Debe aceptar la política de tratamiento de datos personales para crear la cuenta.";
    }

    return $errores;
}

function validarPerfil($datos)
{
    $errores = [];
    if (mb_strlen(trim($datos["nombre_completo"] ?? "")) < 3) {
        $errores["nombre_completo"] = "Escriba su nombre completo (mínimo 3 caracteres).";
    }
    $correo = trim($datos["correo"] ?? "");
    if ($correo !== "" && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores["correo"] = "El correo electrónico no es válido.";
    }
    $tel = trim($datos["telefono"] ?? "");
    if ($tel !== "" && !preg_match('/^[0-9+\s-]{7,20}$/', $tel)) {
        $errores["telefono"] = "El teléfono tiene un formato inválido.";
    }
    if (mb_strlen(trim($datos["cargo"] ?? "")) > 100) {
        $errores["cargo"] = "Máximo 100 caracteres.";
    }
    return $errores;
}
?>
