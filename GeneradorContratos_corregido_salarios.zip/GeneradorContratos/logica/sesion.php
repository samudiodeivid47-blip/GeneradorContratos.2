<?php
/*
 * Sesión, perfiles y control de acceso.
 *
 * Perfiles:
 *   administrador : todo, incluida la gestión de usuarios.
 *   supervisor    : ve todo, revisa/aprueba contratos, controla riesgos y
 *                   atiende solicitudes de datos personales.
 *   usuario       : solo ve y modifica lo que él mismo registró.
 */
require_once __DIR__ . "/seguridad.php";

function usuarioActual()
{
    return $_SESSION["usuario"] ?? null;
}

// Cierra la sesión si estuvo inactiva demasiado tiempo.
function verificarInactividad()
{
    if (empty($_SESSION["usuario"]["id"])) {
        return;
    }
    $limite = SESION_INACTIVIDAD_MIN * 60;
    $ultima = $_SESSION["ultima_actividad"] ?? time();
    if (time() - $ultima > $limite) {
        $_SESSION = [];
        $_SESSION["mensaje_login"] = "Su sesión se cerró por inactividad. Inicie sesión de nuevo.";
        return;
    }
    $_SESSION["ultima_actividad"] = time();
}

function estaAutenticado()
{
    verificarInactividad();
    return !empty($_SESSION["usuario"]["id"]);
}

function rolActual()
{
    return estaAutenticado() ? ($_SESSION["usuario"]["rol"] ?? "") : "";
}

function esAdministrador()
{
    return rolActual() === "administrador";
}

// Supervisor o administrador: pueden revisar contratos y ver todos los registros.
function puedeSupervisar()
{
    return in_array(rolActual(), ["administrador", "supervisor"], true);
}

function nombreRol($rol)
{
    return ["administrador" => "Administrador", "supervisor" => "Supervisor", "usuario" => "Usuario"][$rol] ?? $rol;
}

function requerirLogin($rutaLogin)
{
    if (!estaAutenticado()) {
        if (empty($_SESSION["mensaje_login"])) {
            $_SESSION["mensaje_login"] = "Inicie sesión para continuar.";
        }
        header("Location: " . $rutaLogin);
        exit();
    }
}

// Exige uno de los perfiles indicados; si no, vuelve al panel con un aviso.
function requerirRol(array $roles, $rutaLogin, $rutaPanel)
{
    requerirLogin($rutaLogin);
    if (!in_array(rolActual(), $roles, true)) {
        flash("error", "No tiene permisos para acceder a esa sección.");
        header("Location: " . $rutaPanel);
        exit();
    }
}

// Un usuario normal solo ve lo que él registró; supervisor y administrador ven todo.
function esPropietario($registro, $campo)
{
    $u = usuarioActual();
    return $u !== null && isset($registro[$campo]) && (int) $registro[$campo] === (int) $u["id"];
}

function puedeVerContrato($contrato)
{
    return puedeSupervisar() || esPropietario($contrato, "usuario_id");
}

function puedeVerEmpresa($empresa)
{
    return puedeSupervisar() || esPropietario($empresa, "creado_por");
}

function puedeVerTrabajador($trabajador)
{
    return puedeSupervisar() || esPropietario($trabajador, "creado_por");
}
?>
