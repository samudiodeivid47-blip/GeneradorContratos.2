<?php
// Configuración general del sistema.
// Si cambia el entorno (servidor, credenciales), solo se modifica este archivo.

define("SERVIDOR", "localhost");
define("USUARIO", "root");          // En producción use un usuario con permisos limitados (ver README).
define("PASSWORD", "");
define("BASE_DATOS", "contratos_obra_labor");

// Jornada máxima legal vigente en horas semanales.
// Ley 2101 de 2021: reducción gradual hasta 42 horas semanales
// (42 horas desde el 15 de julio de 2026). Verificar vigencia antes
// de usar en producción.
define("JORNADA_MAXIMA_SEMANAL", 42);

// Período de prueba: el Código Sustantivo del Trabajo (art. 78) lo limita a
// dos (2) meses. Se valida como 60 días. [VERIFICAR con un abogado laboralista]
define("PERIODO_PRUEBA_MAX_DIAS", 60);

date_default_timezone_set("America/Bogota");

// ---------------------------------------------------------------------
// SEGURIDAD
// ---------------------------------------------------------------------
define("SESION_INACTIVIDAD_MIN", 30);   // minutos sin actividad antes de cerrar la sesión
define("MAX_INTENTOS_LOGIN", 5);        // intentos fallidos antes de bloquear la cuenta
define("BLOQUEO_MINUTOS", 15);          // duración del bloqueo
define("REGISTRO_PUBLICO", true);       // false = solo el administrador crea cuentas (recomendado en producción)
define("MODO_PRODUCCION", false);       // true = nunca mostrar errores técnicos en pantalla

if (MODO_PRODUCCION) {
    ini_set("display_errors", "0");
}

// ---------------------------------------------------------------------
// TRATAMIENTO DE DATOS PERSONALES (Ley 1581 de 2012)
// Complete estos datos con los de la entidad que usa el sistema: aparecen
// en la política de tratamiento y en la autorización que firma el trabajador.
// ---------------------------------------------------------------------
define("POLITICA_VERSION", "1.0");
define("RESPONSABLE_NOMBRE", "[NOMBRE DE LA MICROEMPRESA O ENTIDAD RESPONSABLE]");
define("RESPONSABLE_NIT", "[NIT]");
define("RESPONSABLE_DIRECCION", "[DIRECCIÓN], Bogotá D.C.");
define("RESPONSABLE_CORREO", "[correo-para-solicitudes-de-datos@ejemplo.co]");
define("RESPONSABLE_TELEFONO", "[TELÉFONO]");

// ---------------------------------------------------------------------
// Cabeceras HTTP de seguridad (se envían en todas las páginas porque
// todas incluyen este archivo antes de escribir cualquier contenido).
// La política CSP bloquea scripts y estilos en línea: por eso el código
// no usa onclick="..." ni style="..." dentro del HTML.
// ---------------------------------------------------------------------
if (PHP_SAPI !== "cli" && !headers_sent()) {
    header_remove("X-Powered-By");
    header("X-Frame-Options: DENY");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: same-origin");
    header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; "
         . "style-src 'self'; script-src 'self'; form-action 'self'; "
         . "frame-ancestors 'none'; base-uri 'self'");
    // Las páginas con datos personales no deben quedar guardadas en la caché del navegador.
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
}

// ---------------------------------------------------------------------
// Sesión. Cookie httponly (el JavaScript no la lee), SameSite=Lax y
// "secure" automático cuando el sitio se sirve por HTTPS.
// ---------------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $https = !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off";
    ini_set("session.use_strict_mode", "1");
    ini_set("session.use_only_cookies", "1");
    session_set_cookie_params([
        "httponly" => true,
        "samesite" => "Lax",
        "secure"   => $https,
    ]);
    session_start();
}
?>
