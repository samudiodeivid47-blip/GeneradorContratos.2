<?php
require_once __DIR__ . "/config.php";

// Los errores de MySQL se lanzan como excepciones (mysqli_sql_exception).
// Cada proceso las captura y muestra un mensaje general al usuario; el
// detalle técnico solo va al registro de errores del servidor.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conexion = new mysqli(SERVIDOR, USUARIO, PASSWORD, BASE_DATOS);
    $conexion->set_charset("utf8mb4");
} catch (Throwable $e) {
    error_log("ContractPro - error de conexión: " . $e->getMessage());
    http_response_code(500);
    die("No fue posible conectar con la base de datos. Revise config/config.php y que MySQL esté encendido.");
}

// ---------------------------------------------------------------------
// Verificación del esquema: si la base de datos es de una versión anterior
// (por ejemplo, a la tabla usuario le faltan columnas) se avisa con claridad
// en vez de fallar con errores confusos. Se comprueba una vez por sesión.
// ---------------------------------------------------------------------
if (empty($_SESSION["esquema_ok"])) {
    $requeridas = [
        "usuario"    => ["correo", "telefono", "cargo", "intentos_fallidos", "bloqueado_hasta", "ultimo_acceso", "politica_aceptada_en", "politica_version"],
        "empresa"    => ["clase_riesgo", "creado_por"],
        "trabajador" => ["autoriza_datos", "autorizacion_fecha", "autorizacion_version", "autorizacion_medio", "autorizacion_registrada_por", "creado_por"],
        "contrato"   => ["labor_transitoria", "fecha_firma", "fecha_terminacion_estimada", "puntaje_riesgo", "nivel_riesgo", "revisado_por", "fecha_revision", "observacion_revision"],
    ];
    $faltan = [];
    try {
        $res = $conexion->query(
            "SELECT table_name AS t, column_name AS c FROM information_schema.columns
              WHERE table_schema = DATABASE() AND table_name IN ('usuario','empresa','trabajador','contrato')"
        );
        $existentes = [];
        foreach ($res as $f) {
            $existentes[strtolower($f["t"])][strtolower($f["c"])] = true;
        }
        foreach ($requeridas as $tabla => $cols) {
            foreach ($cols as $c) {
                if (empty($existentes[$tabla][$c])) {
                    $faltan[] = "$tabla.$c";
                }
            }
        }
        // El rol 'supervisor' debe existir en la tabla usuario.
        $rol = $conexion->query("SHOW COLUMNS FROM usuario LIKE 'rol'")->fetch_assoc();
        if ($rol && strpos($rol["Type"], "supervisor") === false) {
            $faltan[] = "usuario.rol (falta el perfil supervisor)";
        }
    } catch (Throwable $e) {
        error_log("ContractPro - verificación de esquema: " . $e->getMessage());
        $faltan[] = "tablas (no existen o no se pueden leer)";
    }
    if (!empty($faltan)) {
        http_response_code(500);
        die("<p><strong>La base de datos no está al día con esta versión de ContractPro.</strong></p>"
          . "<p>Falta: " . htmlspecialchars(implode(", ", $faltan), ENT_QUOTES, "UTF-8") . ".</p>"
          . "<p>Solución: en phpMyAdmin → <em>Importar</em>, importe de nuevo <code>BASE_DATOS_UNIFICADA.sql</code> "
          . "(actualiza las tablas antiguas sin borrar datos; haga antes una copia con <em>Exportar</em>).</p>");
    }
    $_SESSION["esquema_ok"] = true;
}
?>
