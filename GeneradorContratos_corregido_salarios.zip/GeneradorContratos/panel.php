<?php
require_once __DIR__ . "/config/conexionBDD.php";
require_once __DIR__ . "/logica/sesion.php";
require_once __DIR__ . "/logica/vista.php";
require_once __DIR__ . "/logica/calendario.php";
require_once __DIR__ . "/datos/contratoDAO.php";
require_once __DIR__ . "/datos/solicitudDAO.php";
require_once __DIR__ . "/vistas/_encabezado.php";

requerirLogin("vistas/login.php");

$u = usuarioActual();
$todos = puedeSupervisar();

// Totales por estado y por nivel de riesgo (supervisor ve todo; usuario, lo suyo).
$porEstado = [];
$porNivel = ["bajo" => 0, "medio" => 0, "alto" => 0];
foreach (resumenContratos($conexion, (int) $u["id"], $todos) as $fila) {
    $porEstado[$fila["estado"]] = ($porEstado[$fila["estado"]] ?? 0) + (int) $fila["n"];
    if ($fila["estado"] !== "anulado") {
        $porNivel[$fila["nivel_riesgo"]] += (int) $fila["n"];
    }
}
$proximos = proximosEventos($conexion, (int) $u["id"], $todos, 30);
$solicitudesAbiertas = contarSolicitudesAbiertas($conexion, (int) $u["id"], $todos);

encabezadoPagina("Panel", "");
?>
    <h2>Hola, <?= h($u["nombre_completo"]) ?></h2>
    <p class="subtitulo">Perfil: <strong><?= h(nombreRol($u["rol"])) ?></strong>
        <?= $todos ? "— ve los registros de todos los usuarios" : "— ve solo lo que usted registró" ?></p>

    <?php if (empty($u["politica_ok"])) { ?>
        <div class="mensaje-error-general no-imprimir">
            Falta su aceptación de la <a href="vistas/politicaDatos.php" target="_blank">política de tratamiento de datos</a>
            (versión <?= h(POLITICA_VERSION) ?>).
            <form method="POST" action="procesos/aceptarPolitica.php" class="form-en-linea">
                <?= campoCsrf() ?><button type="submit" class="btn-primario">Acepto la política</button>
            </form>
        </div>
    <?php } ?>

    <div class="tarjetas">
        <a class="tarjeta" href="vistas/listado.php?estado=pendiente_revision"><span class="cifra"><?= (int) ($porEstado["pendiente_revision"] ?? 0) ?></span>Pendientes de revisión</a>
        <a class="tarjeta" href="vistas/listado.php?estado=aprobado"><span class="cifra"><?= (int) ($porEstado["aprobado"] ?? 0) ?></span>Aprobados</a>
        <a class="tarjeta" href="vistas/listado.php?estado=rechazado"><span class="cifra"><?= (int) ($porEstado["rechazado"] ?? 0) ?></span>Rechazados</a>
        <a class="tarjeta riesgo-alto-tarjeta" href="vistas/listado.php?nivel=alto"><span class="cifra"><?= $porNivel["alto"] ?></span>Riesgo alto</a>
        <a class="tarjeta" href="vistas/listado.php?nivel=medio"><span class="cifra"><?= $porNivel["medio"] ?></span>Riesgo medio</a>
        <a class="tarjeta" href="vistas/solicitudes.php"><span class="cifra"><?= $solicitudesAbiertas ?></span>Solicitudes de datos abiertas</a>
    </div>

    <div class="barra-acciones">
        <a href="vistas/contratoForm.php" class="btn-primario">Nuevo contrato</a>
        <a href="asistente.php" class="btn-secundario">Asistente de 3 pasos</a>
        <a href="vistas/calendario.php" class="btn-secundario">Calendario</a>
        <?php if ($todos) { ?><a href="vistas/supervision.php" class="btn-secundario">Panel de supervisión</a><?php } ?>
    </div>

    <h3>Próximos 30 días</h3>
    <?php if (empty($proximos)) { ?>
        <p>No hay fechas de contratos ni vencimientos en los próximos 30 días.</p>
    <?php } else { ?>
        <ul class="lista-eventos">
        <?php foreach ($proximos as $fecha => $lista) { foreach ($lista as $e) { ?>
            <li><span class="insignia ev-<?= h($e["tipo"]) ?>"><?= h(fechaCorta($fecha)) ?></span>
                <?php if ($e["enlace"]) { ?><a href="vistas/<?= h($e["enlace"]) ?>"><?= h($e["titulo"]) ?></a><?php } else { echo h($e["titulo"]); } ?>
                <small>— <?= h($e["detalle"]) ?></small></li>
        <?php } } ?>
        </ul>
    <?php } ?>
<?php piePagina(""); ?>
