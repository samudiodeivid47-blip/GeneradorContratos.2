<?php
require_once __DIR__ . "/../logica/riesgo.php";
/*
 * DAO de contrato. Concentra todo el acceso SQL a la tabla contrato.
 */

// Campos del contrato que llegan del formulario y su tipo para bind_param.
// Se define una sola vez para que el INSERT y el UPDATE nunca se desordenen.
function camposContrato()
{
    return [
        "empresa_id" => "i", "trabajador_id" => "i",
        "descripcion_obra" => "s", "cargo" => "s", "funciones" => "s", "lugar_ejecucion" => "s",
        "labor_transitoria" => "i", "salario" => "d", "auxilio_transporte" => "d",
        "periodicidad_pago" => "s", "forma_pago" => "s", "jornada" => "s", "horas_semanales" => "d",
        "horario" => "s", "fecha_firma" => "s", "fecha_inicio" => "s", "fecha_terminacion_estimada" => "s",
        "condicion_terminacion" => "s", "tiene_periodo_prueba" => "i", "duracion_periodo_prueba_dias" => "i",
        "beneficios_extralegales" => "s", "observaciones" => "s",
    ];
}

// Deja los datos del formulario listos para guardar (fechas vacías = NULL, firma por defecto = hoy).
function normalizarDatosContrato($d)
{
    foreach (["fecha_terminacion_estimada", "horario", "beneficios_extralegales", "observaciones"] as $c) {
        if (!isset($d[$c]) || trim((string) $d[$c]) === "") {
            $d[$c] = null;
        }
    }
    if (empty($d["fecha_firma"])) {
        $d["fecha_firma"] = date("Y-m-d");
    }
    if (empty($d["tiene_periodo_prueba"])) {
        $d["duracion_periodo_prueba_dias"] = null;
    }
    $d["salario"] = (float) $d["salario"];
    $d["auxilio_transporte"] = (float) ($d["auxilio_transporte"] ?? 0);
    $d["horas_semanales"] = (float) $d["horas_semanales"];
    return $d;
}

function insertarContrato($conexion, $d, $usuarioId)
{
    $campos = camposContrato();
    $d = normalizarDatosContrato($d);
    $columnas = implode(", ", array_keys($campos));
    $marcas = implode(",", array_fill(0, count($campos), "?"));
    $stmt = $conexion->prepare(
        "INSERT INTO contrato ($columnas, usuario_id, estado, fecha_generacion)
         VALUES ($marcas, ?, 'pendiente_revision', NOW())"
    );
    $valores = [];
    foreach (array_keys($campos) as $c) {
        $valores[] = $d[$c];
    }
    $valores[] = $usuarioId;
    $stmt->bind_param(implode("", $campos) . "i", ...$valores);
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return $id ?: false;
}

// Corrige un contrato (solo permitido si está rechazado) y lo manda otra vez a revisión.
function actualizarContrato($conexion, $id, $d)
{
    $campos = camposContrato();
    $d = normalizarDatosContrato($d);
    $sets = implode(", ", array_map(fn($c) => "$c = ?", array_keys($campos)));
    $stmt = $conexion->prepare(
        "UPDATE contrato SET $sets, estado = 'pendiente_revision', revisado_por = NULL,
                fecha_revision = NULL, observacion_revision = NULL WHERE id = ?"
    );
    $valores = [];
    foreach (array_keys($campos) as $c) {
        $valores[] = $d[$c];
    }
    $valores[] = $id;
    $stmt->bind_param(implode("", $campos) . "i", ...$valores);
    $stmt->execute();
    $stmt->close();
}

function buscarContratoPorId($conexion, $id)
{
    $stmt = $conexion->prepare(
        "SELECT c.*,
                e.tipo_empleador, e.razon_social, e.nit, e.representante_legal,
                e.documento_representante, e.direccion AS empresa_direccion,
                e.ciudad AS empresa_ciudad, e.departamento AS empresa_departamento,
                e.telefono AS empresa_telefono, e.correo AS empresa_correo,
                e.actividad_economica, e.arl, e.clase_riesgo, e.creado_por AS empresa_creado_por,
                t.nombre_completo, t.tipo_documento, t.numero_documento, t.fecha_nacimiento,
                t.direccion AS trabajador_direccion, t.ciudad AS trabajador_ciudad,
                t.telefono AS trabajador_telefono, t.correo AS trabajador_correo,
                t.eps, t.fondo_pension, t.autoriza_datos, t.autorizacion_fecha, t.autorizacion_medio,
                u.nombre_completo AS autor_nombre, u.nombre_usuario AS autor_usuario,
                r.nombre_completo AS revisor_nombre
           FROM contrato c
           INNER JOIN empresa e ON c.empresa_id = e.id
           INNER JOIN trabajador t ON c.trabajador_id = t.id
           LEFT JOIN usuario u ON c.usuario_id = u.id
           LEFT JOIN usuario r ON c.revisado_por = r.id
          WHERE c.id = ?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

// Supervisor/administrador ven todos; un usuario normal solo los suyos.
function listarContratos($conexion, $usuarioId, $verTodos, $estado = "", $nivel = "")
{
    $sql = "SELECT c.id, c.usuario_id, c.cargo, c.fecha_inicio, c.fecha_terminacion_estimada, c.estado,
                   c.nivel_riesgo, c.puntaje_riesgo,
                   e.razon_social, t.nombre_completo,
                   u.nombre_usuario AS generado_por,
                   (SELECT COUNT(*) FROM contrato_riesgo r
                     WHERE r.contrato_id = c.id AND r.estado = 'abierto' AND r.puntos >= " . RIESGO_PUNTOS_GRAVE . ") AS graves_abiertos
              FROM contrato c
              INNER JOIN empresa e ON c.empresa_id = e.id
              INNER JOIN trabajador t ON c.trabajador_id = t.id
              LEFT JOIN usuario u ON c.usuario_id = u.id
             WHERE 1 = 1";
    $tipos = "";
    $params = [];
    if (!$verTodos) {
        $sql .= " AND c.usuario_id = ?";
        $tipos .= "i";
        $params[] = $usuarioId;
    }
    if (in_array($estado, ["pendiente_revision", "aprobado", "rechazado", "anulado"], true)) {
        $sql .= " AND c.estado = ?";
        $tipos .= "s";
        $params[] = $estado;
    }
    if (in_array($nivel, ["bajo", "medio", "alto"], true)) {
        $sql .= " AND c.nivel_riesgo = ?";
        $tipos .= "s";
        $params[] = $nivel;
    }
    $sql .= " ORDER BY c.fecha_registro DESC, c.id DESC";
    $stmt = $conexion->prepare($sql);
    if ($tipos !== "") {
        $stmt->bind_param($tipos, ...$params);
    }
    $stmt->execute();
    $filas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $filas;
}

// Cuántos contratos activos (no anulados ni rechazados) tiene ya el trabajador con la empresa.
function contarContratosSucesivos($conexion, $empresaId, $trabajadorId, $excluirId = 0)
{
    $stmt = $conexion->prepare(
        "SELECT COUNT(*) AS n FROM contrato
          WHERE empresa_id = ? AND trabajador_id = ? AND id <> ? AND estado IN ('pendiente_revision','aprobado')"
    );
    $stmt->bind_param("iii", $empresaId, $trabajadorId, $excluirId);
    $stmt->execute();
    $n = (int) $stmt->get_result()->fetch_assoc()["n"];
    $stmt->close();
    return $n;
}

function guardarResultadoRiesgo($conexion, $contratoId, $puntaje, $nivel)
{
    $stmt = $conexion->prepare("UPDATE contrato SET puntaje_riesgo = ?, nivel_riesgo = ? WHERE id = ?");
    $stmt->bind_param("isi", $puntaje, $nivel, $contratoId);
    $stmt->execute();
    $stmt->close();
}

function cambiarEstadoContrato($conexion, $contratoId, $estado, $revisorId, $observacion)
{
    $stmt = $conexion->prepare(
        "UPDATE contrato SET estado = ?, revisado_por = ?, fecha_revision = NOW(), observacion_revision = ? WHERE id = ?"
    );
    $stmt->bind_param("sisi", $estado, $revisorId, $observacion, $contratoId);
    $stmt->execute();
    $stmt->close();
}

// Cambiar las funciones de un contrato aprobado lo devuelve a revisión.
function volverARevision($conexion, $contratoId)
{
    $stmt = $conexion->prepare(
        "UPDATE contrato SET estado = 'pendiente_revision', revisado_por = NULL,
                fecha_revision = NULL, observacion_revision = NULL WHERE id = ? AND estado = 'aprobado'"
    );
    $stmt->bind_param("i", $contratoId);
    $stmt->execute();
    $stmt->close();
}

function obtenerParametrosLegales($conexion, $anio)
{
    $stmt = $conexion->prepare("SELECT * FROM parametros_legales WHERE anio = ?");
    $stmt->bind_param("i", $anio);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    // Si no hay cifras para el año actual se usa el año más reciente cargado.
    if (!$fila) {
        $fila = $conexion->query("SELECT * FROM parametros_legales ORDER BY anio DESC LIMIT 1")->fetch_assoc();
    }
    return $fila;
}

// ---------- Fechas para el calendario ----------
// Devuelve los contratos visibles cuyas fechas caen entre $desde y $hasta (Y-m-d).
function contratosParaCalendario($conexion, $desde, $hasta, $usuarioId, $verTodos)
{
    $sql = "SELECT c.id, c.cargo, c.estado, c.fecha_firma, c.fecha_inicio, c.fecha_terminacion_estimada,
                   c.tiene_periodo_prueba, c.duracion_periodo_prueba_dias,
                   e.razon_social, t.nombre_completo
              FROM contrato c
              INNER JOIN empresa e ON c.empresa_id = e.id
              INNER JOIN trabajador t ON c.trabajador_id = t.id
             WHERE c.estado <> 'anulado'
               AND (c.fecha_inicio BETWEEN ? AND ?
                 OR c.fecha_firma BETWEEN ? AND ?
                 OR c.fecha_terminacion_estimada BETWEEN ? AND ?
                 OR (c.tiene_periodo_prueba = 1
                     AND DATE_ADD(c.fecha_inicio, INTERVAL (c.duracion_periodo_prueba_dias - 1) DAY) BETWEEN ? AND ?))";
    $tipos = "ssssssss";
    $params = [$desde, $hasta, $desde, $hasta, $desde, $hasta, $desde, $hasta];
    if (!$verTodos) {
        $sql .= " AND c.usuario_id = ?";
        $tipos .= "i";
        $params[] = $usuarioId;
    }
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param($tipos, ...$params);
    $stmt->execute();
    $filas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $filas;
}

// ---------- Panel / supervisión ----------
function resumenContratos($conexion, $usuarioId, $verTodos)
{
    $sql = "SELECT estado, nivel_riesgo, COUNT(*) AS n FROM contrato";
    if (!$verTodos) {
        $stmt = $conexion->prepare($sql . " WHERE usuario_id = ? GROUP BY estado, nivel_riesgo");
        $stmt->bind_param("i", $usuarioId);
    } else {
        $stmt = $conexion->prepare($sql . " GROUP BY estado, nivel_riesgo");
    }
    $stmt->execute();
    $filas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $filas;
}

function actividadPorUsuario($conexion)
{
    return $conexion->query(
        "SELECT u.nombre_completo, u.nombre_usuario, u.rol,
                COUNT(c.id) AS contratos,
                SUM(c.estado = 'pendiente_revision') AS pendientes,
                SUM(c.estado = 'rechazado') AS rechazados,
                SUM(c.nivel_riesgo = 'alto') AS riesgo_alto,
                MAX(c.fecha_registro) AS ultimo
           FROM usuario u LEFT JOIN contrato c ON c.usuario_id = u.id
          GROUP BY u.id ORDER BY contratos DESC, u.nombre_completo"
    )->fetch_all(MYSQLI_ASSOC);
}
?>
