<?php
/*
 * DAO de usuario. Todo el SQL de la tabla usuario está aquí (consultas preparadas).
 */

function buscarUsuarioPorNombre($conexion, $nombreUsuario)
{
    $stmt = $conexion->prepare("SELECT * FROM usuario WHERE nombre_usuario = ?");
    $stmt->bind_param("s", $nombreUsuario);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

function buscarUsuarioPorId($conexion, $id)
{
    $stmt = $conexion->prepare("SELECT * FROM usuario WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

function contarUsuarios($conexion)
{
    return (int) $conexion->query("SELECT COUNT(*) AS total FROM usuario")->fetch_assoc()["total"];
}

function contarAdministradoresActivos($conexion)
{
    return (int) $conexion->query(
        "SELECT COUNT(*) AS total FROM usuario WHERE rol = 'administrador' AND activo = 1"
    )->fetch_assoc()["total"];
}

// Devuelve el id nuevo o false (por ejemplo, si el usuario ya existe).
function insertarUsuario($conexion, $nombreUsuario, $nombreCompleto, $correo, $claveHash, $rol, $versionPolitica)
{
    try {
        $correo = $correo !== "" ? $correo : null;
        $stmt = $conexion->prepare(
            "INSERT INTO usuario (nombre_completo, nombre_usuario, correo, clave_hash, rol,
                                  politica_aceptada_en, politica_version)
             VALUES (?,?,?,?,?,IF(? IS NULL, NULL, NOW()),?)"
        );
        $stmt->bind_param("sssssss", $nombreCompleto, $nombreUsuario, $correo, $claveHash, $rol, $versionPolitica, $versionPolitica);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        return $id ?: false;
    } catch (Throwable $e) {
        error_log("insertarUsuario: " . $e->getMessage());
        return false;
    }
}

function aceptarPoliticaUsuario($conexion, $id, $version)
{
    $stmt = $conexion->prepare("UPDATE usuario SET politica_aceptada_en = NOW(), politica_version = ? WHERE id = ?");
    $stmt->bind_param("si", $version, $id);
    $stmt->execute();
    $stmt->close();
}

function listarUsuarios($conexion)
{
    return $conexion->query(
        "SELECT u.*, (SELECT COUNT(*) FROM contrato c WHERE c.usuario_id = u.id) AS contratos
         FROM usuario u ORDER BY u.rol, u.nombre_completo"
    )->fetch_all(MYSQLI_ASSOC);
}

// ---------- Control de intentos de inicio de sesión ----------
function registrarIntentoFallido($conexion, $id)
{
    // Al llegar al máximo se bloquea la cuenta. (MySQL evalúa las asignaciones de izquierda a derecha:
    // por eso bloqueado_hasta va ANTES de aumentar el contador.)
    $stmt = $conexion->prepare(
        "UPDATE usuario
            SET bloqueado_hasta = IF(intentos_fallidos + 1 >= ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), bloqueado_hasta),
                intentos_fallidos = intentos_fallidos + 1
          WHERE id = ?"
    );
    $max = MAX_INTENTOS_LOGIN;
    $min = BLOQUEO_MINUTOS;
    $stmt->bind_param("iii", $max, $min, $id);
    $stmt->execute();
    $stmt->close();
}

function registrarAccesoCorrecto($conexion, $id)
{
    $stmt = $conexion->prepare(
        "UPDATE usuario SET intentos_fallidos = 0, bloqueado_hasta = NULL, ultimo_acceso = NOW() WHERE id = ?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

function cuentaBloqueada($usuario)
{
    return !empty($usuario["bloqueado_hasta"]) && strtotime($usuario["bloqueado_hasta"]) > time();
}

// ---------- Perfil y administración ----------
function actualizarPerfil($conexion, $id, $nombre, $correo, $telefono, $cargo)
{
    $correo = $correo !== "" ? $correo : null;
    $telefono = $telefono !== "" ? $telefono : null;
    $cargo = $cargo !== "" ? $cargo : null;
    $stmt = $conexion->prepare(
        "UPDATE usuario SET nombre_completo = ?, correo = ?, telefono = ?, cargo = ? WHERE id = ?"
    );
    $stmt->bind_param("ssssi", $nombre, $correo, $telefono, $cargo, $id);
    $stmt->execute();
    $stmt->close();
}

function actualizarClave($conexion, $id, $claveHash)
{
    $stmt = $conexion->prepare("UPDATE usuario SET clave_hash = ? WHERE id = ?");
    $stmt->bind_param("si", $claveHash, $id);
    $stmt->execute();
    $stmt->close();
}

function cambiarRolUsuario($conexion, $id, $rol)
{
    $stmt = $conexion->prepare("UPDATE usuario SET rol = ? WHERE id = ?");
    $stmt->bind_param("si", $rol, $id);
    $stmt->execute();
    $stmt->close();
}

function cambiarActivoUsuario($conexion, $id, $activo)
{
    $stmt = $conexion->prepare("UPDATE usuario SET activo = ? WHERE id = ?");
    $stmt->bind_param("ii", $activo, $id);
    $stmt->execute();
    $stmt->close();
}

function desbloquearUsuario($conexion, $id)
{
    $stmt = $conexion->prepare("UPDATE usuario SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
?>
