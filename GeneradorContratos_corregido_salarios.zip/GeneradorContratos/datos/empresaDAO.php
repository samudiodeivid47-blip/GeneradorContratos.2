<?php
/*
 * DAO de empresa (empleador).
 */

function insertarEmpresa($conexion, $d, $usuarioId)
{
    $stmt = $conexion->prepare(
        "INSERT INTO empresa
            (tipo_empleador, razon_social, nit, representante_legal, documento_representante,
             direccion, ciudad, departamento, telefono, correo, actividad_economica, arl,
             clase_riesgo, creado_por)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    $stmt->bind_param(
        "ssssssssssssii",
        $d["tipo_empleador"], $d["razon_social"], $d["nit"], $d["representante_legal"],
        $d["documento_representante"], $d["direccion"], $d["ciudad"], $d["departamento"],
        $d["telefono"], $d["correo"], $d["actividad_economica"], $d["arl"],
        $d["clase_riesgo"], $usuarioId
    );
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return $id ?: false;
}

function actualizarEmpresa($conexion, $id, $d)
{
    $stmt = $conexion->prepare(
        "UPDATE empresa SET tipo_empleador = ?, razon_social = ?, nit = ?, representante_legal = ?,
                documento_representante = ?, direccion = ?, ciudad = ?, departamento = ?,
                telefono = ?, correo = ?, actividad_economica = ?, arl = ?, clase_riesgo = ?
          WHERE id = ?"
    );
    $stmt->bind_param(
        "ssssssssssssii",
        $d["tipo_empleador"], $d["razon_social"], $d["nit"], $d["representante_legal"],
        $d["documento_representante"], $d["direccion"], $d["ciudad"], $d["departamento"],
        $d["telefono"], $d["correo"], $d["actividad_economica"], $d["arl"],
        $d["clase_riesgo"], $id
    );
    $stmt->execute();
    $stmt->close();
}

function buscarEmpresaPorNit($conexion, $nit)
{
    $stmt = $conexion->prepare("SELECT * FROM empresa WHERE nit = ?");
    $stmt->bind_param("s", $nit);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

function buscarEmpresaPorId($conexion, $id)
{
    $stmt = $conexion->prepare("SELECT * FROM empresa WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

// Supervisor/administrador ven todas; un usuario solo las que registró.
function listarEmpresas($conexion, $usuarioId, $verTodas, $busqueda = "")
{
    $like = "%" . $busqueda . "%";
    $sql = "SELECT e.*, u.nombre_usuario AS registrada_por,
                   (SELECT COUNT(*) FROM contrato c WHERE c.empresa_id = e.id) AS contratos
              FROM empresa e LEFT JOIN usuario u ON e.creado_por = u.id
             WHERE (e.razon_social LIKE ? OR e.nit LIKE ?)";
    if ($verTodas) {
        $stmt = $conexion->prepare($sql . " ORDER BY e.razon_social");
        $stmt->bind_param("ss", $like, $like);
    } else {
        $stmt = $conexion->prepare($sql . " AND e.creado_por = ? ORDER BY e.razon_social");
        $stmt->bind_param("ssi", $like, $like, $usuarioId);
    }
    $stmt->execute();
    $filas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $filas;
}
?>
