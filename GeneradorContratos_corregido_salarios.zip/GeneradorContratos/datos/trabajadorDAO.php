<?php
/*
 * DAO de trabajador (incluye la autorización de tratamiento de datos).
 */

function insertarTrabajador($conexion, $d, $usuarioId)
{
    $autoriza = !empty($d["autoriza_datos"]) ? 1 : 0;
    $medio = $autoriza ? $d["autorizacion_medio"] : null;
    $version = $autoriza ? POLITICA_VERSION : null;
    $registradaPor = $autoriza ? $usuarioId : null;
    $fechaAut = $autoriza ? date("Y-m-d H:i:s") : null;

    $stmt = $conexion->prepare(
        "INSERT INTO trabajador
            (nombre_completo, tipo_documento, numero_documento, fecha_nacimiento, direccion,
             ciudad, telefono, correo, eps, fondo_pension,
             autoriza_datos, autorizacion_fecha, autorizacion_version, autorizacion_medio,
             autorizacion_registrada_por, creado_por)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    $stmt->bind_param(
        "ssssssssssisssii",
        $d["nombre_completo"], $d["tipo_documento"], $d["numero_documento"], $d["fecha_nacimiento"],
        $d["direccion"], $d["ciudad"], $d["telefono"], $d["correo"], $d["eps"], $d["fondo_pension"],
        $autoriza, $fechaAut, $version, $medio, $registradaPor, $usuarioId
    );
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return $id ?: false;
}

// Actualiza los datos. La autorización solo se escribe si todavía no existía
// (una autorización ya registrada no se borra editando: se revoca con una solicitud).
function actualizarTrabajador($conexion, $id, $d, $usuarioId, $yaAutorizado)
{
    $stmt = $conexion->prepare(
        "UPDATE trabajador SET nombre_completo = ?, tipo_documento = ?, numero_documento = ?,
                fecha_nacimiento = ?, direccion = ?, ciudad = ?, telefono = ?, correo = ?,
                eps = ?, fondo_pension = ?
          WHERE id = ?"
    );
    $stmt->bind_param(
        "ssssssssssi",
        $d["nombre_completo"], $d["tipo_documento"], $d["numero_documento"], $d["fecha_nacimiento"],
        $d["direccion"], $d["ciudad"], $d["telefono"], $d["correo"], $d["eps"], $d["fondo_pension"], $id
    );
    $stmt->execute();
    $stmt->close();

    if (!$yaAutorizado && !empty($d["autoriza_datos"])) {
        registrarAutorizacionDatos($conexion, $id, $d["autorizacion_medio"], $usuarioId);
    }
}

function registrarAutorizacionDatos($conexion, $trabajadorId, $medio, $usuarioId)
{
    $version = POLITICA_VERSION;
    $stmt = $conexion->prepare(
        "UPDATE trabajador SET autoriza_datos = 1, autorizacion_fecha = NOW(), autorizacion_version = ?,
                autorizacion_medio = ?, autorizacion_registrada_por = ? WHERE id = ?"
    );
    $stmt->bind_param("ssii", $version, $medio, $usuarioId, $trabajadorId);
    $stmt->execute();
    $stmt->close();
}

// La revocatoria de la autorización (derecho del titular) la registra el supervisor al resolver la solicitud.
function revocarAutorizacionDatos($conexion, $trabajadorId)
{
    $stmt = $conexion->prepare(
        "UPDATE trabajador SET autoriza_datos = 0, autorizacion_medio = NULL WHERE id = ?"
    );
    $stmt->bind_param("i", $trabajadorId);
    $stmt->execute();
    $stmt->close();
}

function buscarTrabajadorPorDocumento($conexion, $tipoDocumento, $numeroDocumento)
{
    $stmt = $conexion->prepare("SELECT * FROM trabajador WHERE tipo_documento = ? AND numero_documento = ?");
    $stmt->bind_param("ss", $tipoDocumento, $numeroDocumento);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

function buscarTrabajadorPorId($conexion, $id)
{
    $stmt = $conexion->prepare("SELECT * FROM trabajador WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $fila;
}

function listarTrabajadores($conexion, $usuarioId, $verTodos, $busqueda = "")
{
    $like = "%" . $busqueda . "%";
    $sql = "SELECT t.*, u.nombre_usuario AS registrado_por,
                   (SELECT COUNT(*) FROM contrato c WHERE c.trabajador_id = t.id) AS contratos
              FROM trabajador t LEFT JOIN usuario u ON t.creado_por = u.id
             WHERE (t.nombre_completo LIKE ? OR t.numero_documento LIKE ?)";
    if ($verTodos) {
        $stmt = $conexion->prepare($sql . " ORDER BY t.nombre_completo");
        $stmt->bind_param("ss", $like, $like);
    } else {
        $stmt = $conexion->prepare($sql . " AND t.creado_por = ? ORDER BY t.nombre_completo");
        $stmt->bind_param("ssi", $like, $like, $usuarioId);
    }
    $stmt->execute();
    $filas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $filas;
}
?>
