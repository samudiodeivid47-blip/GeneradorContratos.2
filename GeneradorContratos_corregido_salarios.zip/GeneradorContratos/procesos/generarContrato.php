<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../logica/entradas.php";
require_once __DIR__ . "/../logica/validarEmpresa.php";
require_once __DIR__ . "/../logica/validarTrabajador.php";
require_once __DIR__ . "/../logica/validarContrato.php";
require_once __DIR__ . "/../logica/servicioContrato.php";

/*
 * ASISTENTE de 3 pasos: recibe empresa + trabajador + contrato en un solo
 * envío, valida cada bloque por separado y, si todo es correcto, guarda los
 * tres registros y genera el contrato (queda pendiente de revisión).
 * Alternativa: usar los formularios separados (Empresas, Trabajadores, Nuevo contrato).
 */
requerirLogin("../vistas/login.php");
exigirPost("../asistente.php");
exigirCsrf("../asistente.php");

$datosEmpresa    = leerEmpresaPost();
$datosTrabajador = leerTrabajadorPost();
$datosContrato   = leerContratoPost();

$empresaExistente = $datosEmpresa["nit"] !== "" ? buscarEmpresaPorNit($conexion, $datosEmpresa["nit"]) : null;
$trabajadorExistente = ($datosTrabajador["tipo_documento"] !== "" && $datosTrabajador["numero_documento"] !== "")
    ? buscarTrabajadorPorDocumento($conexion, $datosTrabajador["tipo_documento"], $datosTrabajador["numero_documento"])
    : null;

$parametros = obtenerParametrosLegales($conexion, (int) date("Y"));
$erroresEmpresa    = validarEmpresa($datosEmpresa);
$erroresTrabajador = validarTrabajador($datosTrabajador, !($trabajadorExistente && (int) $trabajadorExistente["autoriza_datos"] === 1));
$erroresContrato   = validarContrato($datosContrato, $parametros);

// Si el NIT / documento ya existen se reutiliza el registro, pero solo si el
// usuario tiene permiso sobre él (los datos de otros usuarios no se enlazan).
if ($empresaExistente && !puedeVerEmpresa($empresaExistente)) {
    $erroresEmpresa["nit"] = "Ya existe una empresa registrada con ese NIT. Pida al supervisor que la habilite.";
}
if ($trabajadorExistente && !puedeVerTrabajador($trabajadorExistente)) {
    $erroresTrabajador["numero_documento"] = "Ya existe un trabajador registrado con ese documento. Pida al supervisor que lo habilite.";
}

if (!empty($erroresEmpresa) || !empty($erroresTrabajador) || !empty($erroresContrato)) {
    $_SESSION["asistente"] = [
        "empresa" => [$datosEmpresa, $erroresEmpresa],
        "trabajador" => [$datosTrabajador, $erroresTrabajador],
        "contrato" => [$datosContrato, $erroresContrato],
    ];
    header("Location: ../asistente.php");
    exit();
}

try {
    $conexion->begin_transaction();

    $empresaId = $empresaExistente ? (int) $empresaExistente["id"] : insertarEmpresa($conexion, $datosEmpresa, (int) usuarioActual()["id"]);

    if ($trabajadorExistente) {
        $trabajadorId = (int) $trabajadorExistente["id"];
        if ((int) $trabajadorExistente["autoriza_datos"] === 0 && !empty($datosTrabajador["autoriza_datos"])) {
            registrarAutorizacionDatos($conexion, $trabajadorId, $datosTrabajador["autorizacion_medio"], (int) usuarioActual()["id"]);
            registrarBitacora($conexion, "autorizacion_datos", "trabajador", $trabajadorId, "Medio: " . $datosTrabajador["autorizacion_medio"]);
        }
    } else {
        $trabajadorId = insertarTrabajador($conexion, $datosTrabajador, (int) usuarioActual()["id"]);
        registrarBitacora($conexion, "autorizacion_datos", "trabajador", $trabajadorId, "Medio: " . $datosTrabajador["autorizacion_medio"]);
    }

    $contratoId = crearContratoYEvaluar($conexion, $datosContrato, $empresaId, $trabajadorId, (int) usuarioActual()["id"]);
    $conexion->commit();
} catch (Throwable $e) {
    $conexion->rollback();
    error_log("generarContrato: " . $e->getMessage());
    $_SESSION["asistente"] = [
        "empresa" => [$datosEmpresa, []],
        "trabajador" => [$datosTrabajador, []],
        "contrato" => [$datosContrato, []],
    ];
    flash("error", "No fue posible generar el contrato. Intente de nuevo; si el problema continúa, avise al administrador.");
    header("Location: ../asistente.php");
    exit();
}

flash("ok", "Contrato generado. Queda pendiente de revisión del supervisor.");
header("Location: ../vistas/verContrato.php?id=" . $contratoId);
exit();
?>
