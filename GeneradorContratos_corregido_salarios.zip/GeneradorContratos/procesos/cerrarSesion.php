<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";

// Cierra la sesión solo por POST con token (evita que otra página cierre la sesión por enlace).
exigirPost("../index.php");
exigirCsrf("../index.php");

if (estaAutenticado()) {
    registrarBitacora($conexion, "logout", "usuario", (int) usuarioActual()["id"], "Cierre de sesión");
}
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $p = session_get_cookie_params();
    setcookie(session_name(), "", time() - 42000, $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
}
session_destroy();

header("Location: ../vistas/login.php");
exit();
?>
