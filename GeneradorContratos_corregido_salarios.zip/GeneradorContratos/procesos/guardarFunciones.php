<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../datos/contratoDAO.php";
require_once __DIR__ . "/../datos/modificacionDAO.php";

/*
 * Cambia las FUNCIONES del trabajador en un contrato ya generado.
 * Cada cambio exige un motivo y queda en contrato_modificacion (qué había,
 * qué hay ahora, quién, cuándo y por qué). Si el contrato estaba aprobado,
 * vuelve a revisión del supervisor.
 */
requerirLogin("../vistas/login.php");
exigirPost("../vistas/listado.php");
exigirCsrf("../vistas/listado.php");

$id = (isset($_POST["id"]) && ctype_digit((string) $_POST["id"])) ? (int) $_POST["id"] : 0;
$contrato = $id > 0 ? buscarContratoPorId($conexion, $id) : null;

// Solo el autor o el administrador, y no sobre un contrato anulado.
if (!$contrato || $contrato["estado"] === "anulado" || !(esPropietario($contrato, "usuario_id") || esAdministrador())) {
    flash("error", "No tiene permiso para modificar las funciones de ese contrato.");
    header("Location: ../vistas/listado.php");
    exit();
}

$funciones = is_string($_POST["funciones"] ?? null) ? trim($_POST["funciones"]) : "";
$motivo = is_string($_POST["motivo"] ?? null) ? trim($_POST["motivo"]) : "";
$errores = [];

if (mb_strlen($funciones) < 20) {
    $errores["funciones"] = "Describa las funciones con más detalle (mínimo 20 caracteres).";
} elseif ($funciones === trim($contrato["funciones"])) {
    $errores["funciones"] = "No hay cambios: el texto es igual al actual.";
}

if (mb_strlen($motivo) < 10) {
    $errores["motivo"] = "Explique el motivo del cambio (mínimo 10 caracteres).";
} elseif (mb_strlen($motivo) > 255) {
    $errores["motivo"] = "El motivo no puede superar 255 caracteres.";
}

if (!empty($errores)) {
    guardarFormulario("funciones", ["funciones" => $funciones, "motivo" => $motivo], $errores);
    header("Location: ../vistas/editarFunciones.php?id=" . $id);
    exit();
}

try {
    $conexion->begin_transaction();
    actualizarFunciones($conexion, $id, $funciones);
    insertarModificacion($conexion, $id, (int) usuarioActual()["id"], "funciones", $contrato["funciones"], $funciones, $motivo);
    volverARevision($conexion, $id);
    registrarBitacora($conexion, "contrato_funciones", "contrato", $id, $motivo);
    $conexion->commit();
} catch (Throwable $e) {
    $conexion->rollback();
    error_log("guardarFunciones: " . $e->getMessage());
    guardarFormulario("funciones", ["funciones" => $funciones, "motivo" => $motivo],
        ["funciones" => "No fue posible guardar el cambio. Intente de nuevo."]);
    header("Location: ../vistas/editarFunciones.php?id=" . $id);
    exit();
}

flash("ok", $contrato["estado"] === "aprobado"
    ? "Las funciones se actualizaron. Como el contrato estaba aprobado, volvió a revisión del supervisor."
    : "Las funciones se actualizaron y el cambio quedó registrado en el historial.");
header("Location: ../vistas/verContrato.php?id=" . $id);
exit();
?>
