<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/usuarioDAO.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../logica/validarUsuario.php";
require_once __DIR__ . "/../logica/entradas.php";

/*
 * Registro de un usuario nuevo (autoregistro).
 *  - Se puede desactivar con REGISTRO_PUBLICO = false (entonces solo el administrador crea cuentas).
 *  - Exige aceptar la política de tratamiento de datos personales.
 *  - Guarda la contraseña con password_hash (nunca en texto plano).
 *  - El primer usuario registrado queda como "administrador"; los demás, como "usuario".
 *    Supervisores y administradores adicionales los asigna el administrador.
 */
exigirPost("../vistas/registro.php");
exigirCsrf("../vistas/registro.php");

if (!REGISTRO_PUBLICO && contarUsuarios($conexion) > 0) {
    $_SESSION["mensaje_login"] = "El registro público está desactivado. Pida su cuenta al administrador.";
    header("Location: ../vistas/login.php");
    exit();
}

$datos = [
    "nombre_completo" => textoPost("nombre_completo"),
    "nombre_usuario"  => textoPost("nombre_usuario"),
    "correo"          => textoPost("correo"),
];
// Las contraseñas no se recortan (los espacios pueden ser parte de la clave).
$clave  = is_string($_POST["clave"] ?? null) ? $_POST["clave"] : "";
$clave2 = is_string($_POST["clave2"] ?? null) ? $_POST["clave2"] : "";
$aceptaPolitica = isset($_POST["acepta_politica"]);

$errores = validarRegistroUsuario($datos, $clave, $clave2, $aceptaPolitica);

if (empty($errores["nombre_usuario"]) && buscarUsuarioPorNombre($conexion, $datos["nombre_usuario"])) {
    $errores["nombre_usuario"] = "Ese nombre de usuario ya está en uso. Elija otro.";
}

if (!empty($errores)) {
    // Se devuelven los datos escritos, pero NUNCA las contraseñas.
    guardarFormulario("registro", $datos, $errores);
    header("Location: ../vistas/registro.php");
    exit();
}

$rol = contarUsuarios($conexion) === 0 ? "administrador" : "usuario";
$id = insertarUsuario($conexion, $datos["nombre_usuario"], $datos["nombre_completo"], $datos["correo"],
                      password_hash($clave, PASSWORD_DEFAULT), $rol, POLITICA_VERSION);

if (!$id) {
    guardarFormulario("registro", $datos, ["nombre_usuario" => "No fue posible crear la cuenta. Intente de nuevo."]);
    header("Location: ../vistas/registro.php");
    exit();
}

registrarBitacora($conexion, "usuario_registro", "usuario", $id, "Cuenta creada con rol $rol; política " . POLITICA_VERSION . " aceptada");
$_SESSION["mensaje_login"] = "Cuenta creada correctamente. Ya puede iniciar sesión.";
header("Location: ../vistas/login.php");
exit();
?>
