<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../datos/usuarioDAO.php";

/*
 * Inicio de sesión.
 *  - Protegido con token CSRF.
 *  - Mensaje de error único: no revela si el usuario existe, si la clave
 *    falló o si la cuenta está bloqueada.
 *  - Tras MAX_INTENTOS_LOGIN intentos fallidos la cuenta se bloquea BLOQUEO_MINUTOS minutos.
 *  - Se ejecuta password_verify aunque el usuario no exista, para que la
 *    respuesta tarde lo mismo en ambos casos.
 */
exigirPost("../vistas/login.php");
exigirCsrf("../vistas/login.php");

const HASH_FALSO = '$2y$10$oBs485SLBVp.KQcm9fttHuJB6kQWN6klcT.C9dkDLKwXtTskE7eAG';

$nombreUsuario = mb_substr(trim($_POST["nombre_usuario"] ?? ""), 0, 30);
$clave = is_string($_POST["clave"] ?? null) ? $_POST["clave"] : "";

$usuario = $nombreUsuario !== "" ? buscarUsuarioPorNombre($conexion, $nombreUsuario) : null;
$bloqueada = $usuario && cuentaBloqueada($usuario);
$claveCorrecta = password_verify($clave, $usuario["clave_hash"] ?? HASH_FALSO);

if ($usuario && (int) $usuario["activo"] === 1 && !$bloqueada && $claveCorrecta) {
    // Identificador de sesión nuevo al autenticarse (previene la fijación de sesión).
    session_regenerate_id(true);
    $_SESSION = [];
    $_SESSION["usuario"] = [
        "id"              => (int) $usuario["id"],
        "nombre_usuario"  => $usuario["nombre_usuario"],
        "nombre_completo" => $usuario["nombre_completo"],
        "rol"             => $usuario["rol"],
        "politica_ok"     => $usuario["politica_version"] === POLITICA_VERSION,
    ];
    $_SESSION["ultima_actividad"] = time();

    registrarAccesoCorrecto($conexion, (int) $usuario["id"]);
    registrarBitacora($conexion, "login_ok", "usuario", (int) $usuario["id"], "Inicio de sesión");
    header("Location: ../panel.php");
    exit();
}

if ($usuario && (int) $usuario["activo"] === 1 && !$bloqueada) {
    registrarIntentoFallido($conexion, (int) $usuario["id"]);
}
registrarBitacora($conexion, $bloqueada ? "login_bloqueado" : "login_fallido", "usuario",
    $usuario ? (int) $usuario["id"] : null, "Usuario digitado: " . $nombreUsuario);

$_SESSION["error_login"] = "Usuario o contraseña incorrectos, o cuenta bloqueada temporalmente.";
$_SESSION["login_usuario"] = $nombreUsuario;
header("Location: ../vistas/login.php");
exit();
?>
