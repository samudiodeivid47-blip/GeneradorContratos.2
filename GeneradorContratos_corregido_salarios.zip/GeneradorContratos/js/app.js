// JavaScript común. No usa código en línea (la política de seguridad CSP lo bloquea).
document.addEventListener("DOMContentLoaded", function () {
    // Importes en pesos colombianos: permite pegar/escribir 1750905, 1.750.905 o 1,750,905.
    // Se muestran con puntos de miles y el servidor vuelve a normalizarlos antes de validar/guardar.
    document.querySelectorAll("input[data-moneda]").forEach(function (campo) {
        function formatearImporte() {
            const digitos = campo.value.replace(/\D/g, "").slice(0, 15);
            campo.value = digitos.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }
        campo.addEventListener("input", formatearImporte);
        campo.addEventListener("blur", formatearImporte);
        if (campo.value) formatearImporte();
    });
    // Botones "Imprimir"
    document.querySelectorAll("[data-imprimir]").forEach(function (b) {
        b.addEventListener("click", function () { window.print(); });
    });

    // Formularios que piden confirmación antes de enviarse.
    document.querySelectorAll("form[data-confirmar]").forEach(function (f) {
        f.addEventListener("submit", function (e) {
            if (!window.confirm(f.getAttribute("data-confirmar"))) e.preventDefault();
        });
    });

    // Representante legal solo para persona jurídica.
    const tipo = document.querySelector('[name="tipo_empleador"]');
    const grupoRep = document.getElementById("grupoRepresentante");
    function actualizarRepresentante() {
        if (tipo && grupoRep) grupoRep.classList.toggle("oculto", tipo.value !== "juridica");
    }
    if (tipo) { tipo.addEventListener("change", actualizarRepresentante); actualizarRepresentante(); }

    // Duración del período de prueba solo si se marca el período.
    const chk = document.querySelector('[name="tiene_periodo_prueba"]');
    const duracion = document.querySelector('[name="duracion_periodo_prueba_dias"]');
    const campoDur = duracion ? duracion.closest(".campo") : null;
    function actualizarPrueba() {
        if (chk && campoDur) campoDur.classList.toggle("oculto", !chk.checked);
    }
    if (chk) { chk.addEventListener("change", actualizarPrueba); actualizarPrueba(); }

    // Filtros que se envían al cambiar un select.
    document.querySelectorAll("select[data-autoenviar]").forEach(function (s) {
        s.addEventListener("change", function () { s.form.submit(); });
    });

    // Departamento -> Ciudad (listas desplegables dependientes) con la opción "Otra ciudad...".
    const grupoUb = document.getElementById("grupoUbicacion");
    if (grupoUb) {
        const mapa = JSON.parse(grupoUb.getAttribute("data-ubicacion") || "{}");
        const selDep = document.getElementById("selDepartamento");
        const selCiu = document.getElementById("selCiudad");
        const otra = document.getElementById("inpCiudadOtra");
        const OTRA = "__otra__";

        function opcion(valor, texto) {
            const o = document.createElement("option");
            o.value = valor;
            o.textContent = texto;
            return o;
        }
        function mostrarOtra() {
            const es = selCiu.value === OTRA;
            otra.classList.toggle("oculto", !es);
            if (!es) otra.value = "";
        }
        function llenarCiudades(dep, valor) {
            selCiu.innerHTML = "";
            if (!mapa[dep]) {
                selCiu.appendChild(opcion("", "Seleccione primero el departamento"));
                mostrarOtra();
                return;
            }
            selCiu.appendChild(opcion("", "Seleccione..."));
            mapa[dep].forEach(function (c) { selCiu.appendChild(opcion(c, c)); });
            selCiu.appendChild(opcion(OTRA, "Otra ciudad..."));
            if (valor && mapa[dep].indexOf(valor) !== -1) {
                selCiu.value = valor;
            } else if (valor) {
                selCiu.value = OTRA;     // ciudad guardada que no está en la lista
                otra.value = valor;
            }
            mostrarOtra();
        }
        selDep.addEventListener("change", function () { llenarCiudades(selDep.value, ""); });
        selCiu.addEventListener("change", mostrarOtra);
        let guardada = grupoUb.getAttribute("data-ciudad") || "";
        if (guardada === "Bogotá") guardada = "Bogotá D.C.";   // valor antiguo escrito a mano
        llenarCiudades(selDep.value, guardada);
    }

    // Ciudad del trabajador: lista de ciudades principales y campo para otros municipios.
    const grupoCiudadTrabajador = document.getElementById("grupoCiudadTrabajador");
    if (grupoCiudadTrabajador) {
        const selectCiudadTrabajador = document.getElementById("selCiudadTrabajador");
        const otraCiudadTrabajador = document.getElementById("inpCiudadTrabajadorOtra");
        function mostrarOtraCiudadTrabajador() {
            const esOtra = selectCiudadTrabajador.value === "__otra__";
            otraCiudadTrabajador.classList.toggle("oculto", !esOtra);
            otraCiudadTrabajador.required = esOtra;
            if (!esOtra) otraCiudadTrabajador.value = "";
        }
        const ciudadGuardada = grupoCiudadTrabajador.getAttribute("data-ciudad") || "";
        if (ciudadGuardada && !Array.from(selectCiudadTrabajador.options).some(o => o.value === ciudadGuardada)) {
            selectCiudadTrabajador.value = "__otra__";
            otraCiudadTrabajador.value = ciudadGuardada;
        }
        selectCiudadTrabajador.addEventListener("change", mostrarOtraCiudadTrabajador);
        mostrarOtraCiudadTrabajador();
    }
});
