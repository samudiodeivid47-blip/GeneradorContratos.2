# ContractPro v3 — Generador de contratos por obra o labor determinada

Aplicación web en PHP + MySQL para microempresas de Bogotá. Esta versión agrega a la versión con
login: **fechas, ley aplicable, calendario, formularios separados, seguridad, control de riesgo,
perfiles (administrador / supervisor / usuario) y tratamiento de datos personales (Ley 1581)**,
más datos de prueba (12 registros por tabla principal).

## 1. Instalación (XAMPP)

1. Copia la carpeta `GeneradorContratos` en `C:\xampp\htdocs\` y enciende **Apache** y **MySQL**.
2. En `http://localhost/phpmyadmin` → **Importar** → `BD/BASE_DATOS_UNIFICADA.sql`. Es el **único** SQL de instalación:
   crea la base `contratos_obra_labor` con sus 10 tablas y se puede importar más de una vez sin errores.
3. Si `root` tiene contraseña, escríbela en `config/config.php`. Abre `http://localhost/GeneradorContratos/`: verás la **portada pública** (`index.php`) que explica de qué se trata; el trabajo diario se hace en el **panel** (`panel.php`), al que se llega tras ingresar.
4. Sin datos de prueba, **el primer usuario que se registre queda como administrador**.

**Datos de demostración (opcional):** con la base vacía, importa `BD/datos_prueba.sql` (3 usuarios, 12 empresas,
12 trabajadores, 12 contratos, 12 normas, 3 solicitudes; todo ficticio). Usuarios `admin`, `supervisor`, `usuario1`,
clave de todos `Demo2026Segura`. **Bórralos antes de usar datos reales.**

**Si ya tienes una base de la versión anterior:** haz una copia (Exportar) e importa el mismo
`BD/BASE_DATOS_UNIFICADA.sql`. Detecta las tablas viejas y les agrega solo lo que falta (por ejemplo `usuario.correo`,
`intentos_fallidos` y el perfil `supervisor`) sin borrar datos; los contratos «generado» o «borrador» pasan a
«pendiente de revisión». Si lo olvidas, la aplicación muestra un aviso con lo que falta.

## 2. Qué se agregó (y dónde)

| Pedido | Qué hace | Dónde |
|---|---|---|
| **Fechas** | Firma, inicio, fin estimado y fin del período de prueba; validadas (fecha real, fin > inicio, prueba ≤ 60 días y ≤ duración de la obra). Aparecen en el contrato impreso. | `logica/validarContrato.php`, `plantillas/` |
| **Ley** | Tabla `norma_legal` (12 normas, con estado verificada / por verificar), pantalla *Normativa*, sección «Marco legal aplicable» en el contrato. | `vistas/normativa.php` |
| **Calendario** | Mes con firmas, inicios, fin de prueba, fin estimado, vencimiento de solicitudes de datos, **festivos de Colombia** (Ley Emiliani, calculados) y fechas legales; exporta a `.ics`. | `vistas/calendario.php`, `logica/festivos.php` |
| **10 registros mínimo** | 12 empresas, 12 trabajadores, 12 contratos, 12 normas, 3 usuarios, 3 solicitudes. | `BD/datos_prueba.sql` |
| **Formularios separados** | Empresas, Trabajadores y Contrato tienen cada uno su formulario (registrar / consultar / actualizar). El asistente de 3 pasos se conserva. En empresa, **Departamento** y **Ciudad** son listas desplegables (32 departamentos; la ciudad depende del departamento y tiene «Otra ciudad…»). | `vistas/empresaForm.php`, `trabajadorForm.php`, `contratoForm.php`, `asistente.php` |
| **Seguridad** | CSRF en todos los POST, bloqueo tras 5 intentos (15 min), cierre por inactividad (30 min), claves ≥ 10 con mayúscula/minúscula/número, cookies httponly + SameSite, cabeceras CSP/X-Frame, sin errores técnicos al usuario, acceso por propietario, bitácora, `.htaccess` en carpetas internas. | `logica/seguridad.php`, `config/config.php` |
| **Control de riesgo** | 15 factores con puntos (bajo / medio / alto). El supervisor marca cada factor *mitigado* o *aceptado* (con nota); **no se aprueba con factores graves abiertos**. | `logica/riesgo.php`, `procesos/controlarRiesgo.php` |
| **Perfiles + supervisor** | Administrador / supervisor / usuario; perfil editable y cambio de clave; el supervisor revisa (aprobar, rechazar, anular), ve la cola por riesgo y la actividad de cada usuario. **Nadie revisa un contrato que él mismo generó.** | `vistas/supervision.php`, `usuarios.php`, `perfil.php` |
| **Datos personales** | Política (`politicaDatos.php`), autorización obligatoria del trabajador (quién, cuándo, medio, versión), formato imprimible, solicitudes del titular con plazo en **días hábiles** (consulta 10, reclamo 15), revocatoria que retira la autorización. | `vistas/solicitudes.php`, `plantillas/autorizacionDatos.php` |

Flujo del contrato: `pendiente de revisión → aprobado | rechazado`; el autor corrige un rechazado y vuelve a
revisión; si se editan las funciones de uno aprobado, vuelve a revisión. Un contrato no aprobado se imprime
con la marca «PROYECTO — NO ES VERSIÓN DEFINITIVA».

## 3. Qué debes completar antes de usarlo con datos reales

- `config/config.php`: nombre, NIT, dirección y correo del **responsable del tratamiento** (hoy son `[...]`).
- Pon `MODO_PRODUCCION = true` y, si no quieres registro público, `REGISTRO_PUBLICO = false`.
- Crea un usuario MySQL con permisos limitados (ver el recuadro de abajo) en vez de `root`.
- Usa **HTTPS** (la cookie de sesión se marca `secure` sola) y borra los usuarios de prueba.
- Cada año actualiza `parametros_legales` (salario mínimo y auxilio).
- Un abogado laboralista debe revisar: plantilla del contrato, política de datos y los textos marcados **[VERIFICAR]**.

## 4. Lo que hay que saber (límites honestos)

- Los **puntos del riesgo son criterios del sistema**, no vienen de una norma. Solo lo que cita una ley lo dice en el texto del factor.
- En la base, **las 12 normas quedan como «por verificar»**: confirma cada una en la fuente oficial. (La Ley 2466 de 2025 se contrastó con su texto oficial; que una labor permanente pueda tratarse como indefinida salió de una fuente secundaria y está marcado.)
- **Festivos y fechas legales** (prima, cesantías, jornada 42 h desde 15-jul-2026): se calculan por regla; verifica cada año con el calendario oficial. El período de prueba cuenta el día de inicio como día 1.
- «Supresión» de datos: el sistema **no borra** nada solo; los contratos se conservan por deber legal y el supervisor decide por escrito.
- Los contratos no se eliminan, se **anulan**.
- Bloqueo de cuenta es por usuario (no frena un ataque que pruebe muchos usuarios a la vez); para eso hace falta limitación en el servidor/WAF.
- Los `.htaccess` funcionan en Apache (XAMPP); con otro servidor, bloquea `config/ datos/ logica/ plantillas/ BD/`.

### Usuario MySQL con permisos limitados (recomendado en vez de `root`)
En phpMyAdmin → SQL, cambia la clave y ejecuta; luego escribe ese usuario y clave en `config/config.php`:

    CREATE USER 'contratos_app'@'localhost' IDENTIFIED BY 'ponga-una-clave-larga-aqui';
    GRANT SELECT, INSERT, UPDATE, DELETE ON contratos_obra_labor.* TO 'contratos_app'@'localhost';
    FLUSH PRIVILEGES;

## 5. Qué se probó (y qué falta)

Se ejecutó con PHP 8.3 y MariaDB 10.11 (servidor `php -S`): más de 150 comprobaciones HTTP, sin errores ni avisos de PHP, más pruebas del JavaScript con un navegador simulado (jsdom).
Incluyen registro, login y bloqueo, CSRF, permisos por perfil, acceso a datos de otros usuarios, inyección SQL y XSS,
datos enormes o inválidos, el flujo completo empresa → trabajador → contrato → riesgo → revisión, calendario,
solicitudes de datos, y la instalación nueva, importada 3 veces, más la actualización de una base antigua con datos.
**Falta probar tú:** que los `.htaccess` bloqueen `config/` en el Apache de XAMPP, el diseño en el navegador y el celular,
imprimir a PDF, y la cookie `Secure` con HTTPS real.


## Ajustes de esta versión
- La portada (`index.php`) muestra únicamente el perfil de administrador en la sección de perfiles.
- El formulario del trabajador usa un desplegable con ciudades principales de Colombia y permite introducir otro municipio cuando no aparece en la lista.
- El campo ciudad del empleador conserva el desplegable dependiente del departamento.
- La lista de ciudades es una selección práctica de lugares principales, no un catálogo oficial exhaustivo de todos los municipios colombianos.
