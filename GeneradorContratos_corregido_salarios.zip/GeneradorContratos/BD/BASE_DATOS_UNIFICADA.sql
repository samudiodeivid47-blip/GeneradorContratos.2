-- =====================================================================
-- GENERADOR DE CONTRATOS POR OBRA O LABOR DETERMINADA  (ContractPro v3)
-- Base de datos: contratos_obra_labor
-- Instalación NUEVA. No ejecutar encima de una base existente; primero exporta
-- una copia de seguridad y aplica una migración específica si ya tienes datos.
-- =====================================================================

-- Codificación del archivo: sin esto los acentos pueden guardarse mal (BogotÃ¡) según el programa que importe.
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS contratos_obra_labor
    CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;

USE contratos_obra_labor;

-- ---------------------------------------------------------------------
-- usuario: acceso al sistema con tres perfiles
--   administrador : todo, incluida la gestión de usuarios
--   supervisor    : revisa/aprueba contratos, controla riesgos, atiende
--                   solicitudes de datos personales, ve todo
--   usuario       : genera contratos y solo ve lo que él mismo registró
-- La clave NUNCA se guarda en texto plano (password_hash).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    nombre_usuario VARCHAR(30) NOT NULL,
    correo VARCHAR(120) NULL,
    telefono VARCHAR(20) NULL,
    cargo VARCHAR(100) NULL,
    clave_hash VARCHAR(255) NOT NULL,
    rol ENUM('administrador','supervisor','usuario') NOT NULL DEFAULT 'usuario',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    intentos_fallidos TINYINT UNSIGNED NOT NULL DEFAULT 0,
    bloqueado_hasta DATETIME NULL,
    ultimo_acceso DATETIME NULL,
    politica_aceptada_en DATETIME NULL,
    politica_version VARCHAR(10) NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_usuario_nombre (nombre_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- empresa (empleador). clase_riesgo = clase de riesgo ARL (1 a 5).
-- creado_por: quién la registró (control de acceso por propietario).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS empresa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_empleador ENUM('natural','juridica') NOT NULL,
    razon_social VARCHAR(150) NOT NULL,
    nit VARCHAR(20) NOT NULL,
    representante_legal VARCHAR(150) NULL,
    documento_representante VARCHAR(20) NULL,
    direccion VARCHAR(200) NOT NULL,
    ciudad VARCHAR(80) NOT NULL,
    departamento VARCHAR(80) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(120) NOT NULL,
    actividad_economica VARCHAR(150) NOT NULL,
    arl VARCHAR(100) NULL,
    clase_riesgo TINYINT UNSIGNED NULL,
    creado_por INT NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_empresa_nit (nit),
    CONSTRAINT fk_empresa_usuario FOREIGN KEY (creado_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- trabajador. Guarda además la AUTORIZACIÓN de tratamiento de datos
-- personales (Ley 1581 de 2012): si se dio, cuándo, con qué versión de
-- la política y por qué medio.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS trabajador (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    tipo_documento ENUM('CC','CE','PPT','PEP','PASAPORTE') NOT NULL,
    numero_documento VARCHAR(20) NOT NULL,
    fecha_nacimiento DATE NULL,
    direccion VARCHAR(200) NOT NULL,
    ciudad VARCHAR(80) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(120) NOT NULL,
    eps VARCHAR(100) NULL,
    fondo_pension VARCHAR(100) NULL,
    autoriza_datos TINYINT(1) NOT NULL DEFAULT 0,
    autorizacion_fecha DATETIME NULL,
    autorizacion_version VARCHAR(10) NULL,
    autorizacion_medio ENUM('escrito','electronico') NULL,
    autorizacion_registrada_por INT NULL,
    creado_por INT NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_trabajador_doc (tipo_documento, numero_documento),
    CONSTRAINT fk_trabajador_usuario FOREIGN KEY (creado_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_trabajador_autoriza FOREIGN KEY (autorizacion_registrada_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- contrato. Flujo de estados:
--   pendiente_revision -> aprobado | rechazado (por supervisor/admin)
--   rechazado -> (el autor lo corrige) -> pendiente_revision
--   aprobado -> (si se editan las funciones) -> pendiente_revision
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contrato (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT NOT NULL,
    trabajador_id INT NOT NULL,
    usuario_id INT NULL,

    descripcion_obra TEXT NOT NULL,
    cargo VARCHAR(120) NOT NULL,
    funciones TEXT NOT NULL,
    lugar_ejecucion VARCHAR(200) NOT NULL,
    labor_transitoria TINYINT(1) NOT NULL DEFAULT 1,

    salario DECIMAL(12,2) NOT NULL,
    auxilio_transporte DECIMAL(12,2) NOT NULL DEFAULT 0,
    periodicidad_pago ENUM('semanal','quincenal','mensual') NOT NULL,
    forma_pago ENUM('consignacion','efectivo','transferencia') NOT NULL,

    jornada ENUM('completa','parcial') NOT NULL,
    horas_semanales DECIMAL(4,2) NOT NULL,
    horario VARCHAR(200) NULL,

    -- Fechas del contrato
    fecha_firma DATE NULL,
    fecha_inicio DATE NOT NULL,
    fecha_terminacion_estimada DATE NULL,
    condicion_terminacion TEXT NOT NULL,
    tiene_periodo_prueba TINYINT(1) NOT NULL DEFAULT 0,
    duracion_periodo_prueba_dias INT NULL,

    beneficios_extralegales TEXT NULL,
    observaciones TEXT NULL,

    -- Control de riesgo y revisión
    puntaje_riesgo INT NOT NULL DEFAULT 0,
    nivel_riesgo ENUM('bajo','medio','alto') NOT NULL DEFAULT 'bajo',
    estado ENUM('pendiente_revision','aprobado','rechazado','anulado')
        NOT NULL DEFAULT 'pendiente_revision',
    revisado_por INT NULL,
    fecha_revision DATETIME NULL,
    observacion_revision VARCHAR(500) NULL,

    fecha_generacion DATETIME NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- Índices para las consultas frecuentes (las claves foráneas ya crean los
    -- de empresa_id, trabajador_id, usuario_id y revisado_por).
    KEY idx_contrato_fecha_inicio (fecha_inicio),
    KEY idx_contrato_estado (estado),
    KEY idx_contrato_revision (estado, fecha_revision),

    CONSTRAINT fk_contrato_empresa FOREIGN KEY (empresa_id) REFERENCES empresa(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_contrato_trabajador FOREIGN KEY (trabajador_id) REFERENCES trabajador(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_contrato_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_contrato_revisor FOREIGN KEY (revisado_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- contrato_modificacion (auditoría de cambios de funciones)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contrato_modificacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contrato_id INT NOT NULL,
    usuario_id INT NOT NULL,
    campo VARCHAR(50) NOT NULL,
    valor_anterior TEXT NOT NULL,
    valor_nuevo TEXT NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    fecha_modificacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY idx_mod_contrato_fecha (contrato_id, fecha_modificacion),
    CONSTRAINT fk_mod_contrato FOREIGN KEY (contrato_id) REFERENCES contrato(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_mod_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- contrato_riesgo: CONTROL DE RIESGO. Una fila por factor de riesgo
-- detectado. El supervisor marca cada factor como mitigado o aceptado
-- (con nota) antes de aprobar un contrato con factores graves.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contrato_riesgo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contrato_id INT NOT NULL,
    codigo VARCHAR(30) NOT NULL,
    descripcion VARCHAR(300) NOT NULL,
    recomendacion VARCHAR(300) NOT NULL,
    puntos INT NOT NULL,
    estado ENUM('abierto','mitigado','aceptado') NOT NULL DEFAULT 'abierto',
    nota_control VARCHAR(300) NULL,
    controlado_por INT NULL,
    fecha_control DATETIME NULL,
    UNIQUE KEY uq_riesgo_contrato_codigo (contrato_id, codigo),
    KEY idx_contrato_riesgo_estado (contrato_id, estado),
    CONSTRAINT fk_riesgo_contrato FOREIGN KEY (contrato_id) REFERENCES contrato(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_riesgo_usuario FOREIGN KEY (controlado_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- solicitud_datos: derechos del titular (Ley 1581 de 2012): consultas,
-- reclamos, actualización, rectificación, supresión, revocatoria.
-- fecha_limite se calcula en días hábiles (consulta 10 / reclamo 15).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS solicitud_datos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trabajador_id INT NOT NULL,
    tipo ENUM('consulta','actualizacion','rectificacion','supresion','revocatoria','reclamo') NOT NULL,
    descripcion TEXT NOT NULL,
    estado ENUM('recibida','en_tramite','resuelta','rechazada') NOT NULL DEFAULT 'recibida',
    fecha_recepcion DATE NOT NULL,
    fecha_limite DATE NOT NULL,
    fecha_respuesta DATETIME NULL,
    respuesta TEXT NULL,
    registrada_por INT NULL,
    atendida_por INT NULL,
    KEY idx_solicitud_estado_limite (estado, fecha_limite),
    CONSTRAINT fk_solicitud_trabajador FOREIGN KEY (trabajador_id) REFERENCES trabajador(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_solicitud_registra FOREIGN KEY (registrada_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_solicitud_atiende FOREIGN KEY (atendida_por) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- bitacora: registro de seguridad y de tratamiento de datos (quién hizo
-- qué, cuándo y desde qué IP). No se edita ni se borra desde la app.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NULL,
    accion VARCHAR(40) NOT NULL,
    entidad VARCHAR(30) NOT NULL,
    entidad_id INT NULL,
    detalle VARCHAR(300) NULL,
    ip VARCHAR(45) NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY idx_bitacora_fecha (fecha),
    KEY idx_bitacora_usuario (usuario_id),
    CONSTRAINT fk_bitacora_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ---------------------------------------------------------------------
-- parametros_legales: cifras que cambian cada año.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parametros_legales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    anio INT NOT NULL,
    salario_minimo_mensual DECIMAL(12,2) NOT NULL,
    auxilio_transporte_mensual DECIMAL(12,2) NOT NULL,
    fecha_actualizacion DATE NOT NULL,
    fuente VARCHAR(255) NOT NULL,
    UNIQUE KEY uq_parametros_anio (anio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Los parámetros del año 2026 se cargan abajo con una nota de verificación.
-- Antes de usar cálculos o generar contratos reales, confirme los valores
-- y decretos en fuentes oficiales vigentes.

-- ---------------------------------------------------------------------
-- norma_legal: marco legal que consulta el sistema (se muestra en
-- "Normativa" y alimenta la sección de ley aplicable). 12 normas.
-- estado_verificacion: 'verificada' = confirmada en fuente oficial en
-- el desarrollo; 'por_verificar' = confirmar antes de usar con datos reales.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS norma_legal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    norma VARCHAR(120) NOT NULL,
    tema VARCHAR(120) NOT NULL,
    aplicacion VARCHAR(400) NOT NULL,
    url VARCHAR(255) NULL,
    estado_verificacion ENUM('verificada','por_verificar') NOT NULL DEFAULT 'por_verificar',
    UNIQUE KEY uq_norma (norma)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- ---------------------------------------------------------------------
-- Parámetros legales iniciales para que el validador no opere sin datos.
-- IMPORTANTE: verificar las cifras y la fuente oficial antes de producción.
-- Si ya existe el año, no se sobreescriben automáticamente los valores.
-- ---------------------------------------------------------------------
INSERT INTO parametros_legales
    (anio, salario_minimo_mensual, auxilio_transporte_mensual, fecha_actualizacion, fuente)
VALUES
    (2026, 1750905.00, 249095.00, '2026-02-19',
     'Referencia inicial: Decretos 1469/2025, 1470/2025 y 0159/2026; VERIFICAR en fuente oficial antes de uso')
ON DUPLICATE KEY UPDATE anio = VALUES(anio);

-- ---------------------------------------------------------------------
-- Normativa de referencia. Se marca por_verificar para evitar afirmar que
-- el contenido jurídico está validado automáticamente.
-- ---------------------------------------------------------------------
INSERT INTO norma_legal (norma, tema, aplicacion, url, estado_verificacion) VALUES
('Código Sustantivo del Trabajo', 'Régimen general del contrato de trabajo', 'Revisar disposiciones vigentes aplicables al contrato por obra o labor, jornada, salario, prestaciones, período de prueba y terminación.', 'https://www.suin-juriscol.gov.co/', 'por_verificar'),
('Ley 2466 de 2025', 'Reforma laboral', 'Verificar requisitos vigentes del contrato por duración de obra o labor y sus formalidades.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Ley 2101 de 2021', 'Jornada máxima semanal', 'Verificar cronograma y jornada máxima vigente para la fecha del contrato.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Normativa salario mínimo y auxilio de transporte 2026', 'Salario mínimo y auxilio de transporte', 'Verificar los decretos vigentes y las condiciones individuales de procedencia del auxilio.', 'https://www.mintrabajo.gov.co/', 'por_verificar'),
('Ley 1581 de 2012', 'Protección de datos personales', 'Revisar autorización, finalidades, derechos del titular, política de tratamiento y atención de consultas y reclamos.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Decreto 1074 de 2015', 'Reglamentación de protección de datos', 'Verificar las disposiciones reglamentarias vigentes sobre política, aviso y prueba de autorización.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Ley 1562 de 2012', 'Riesgos laborales', 'Revisar obligaciones vigentes del Sistema General de Riesgos Laborales.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Decreto 1072 de 2015', 'Sector Trabajo y SG-SST', 'Verificar obligaciones vigentes de seguridad y salud en el trabajo.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Decreto 1295 de 1994', 'Sistema de riesgos profesionales', 'Verificar aplicabilidad y modificaciones vigentes en materia de riesgos laborales.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Ley 100 de 1993', 'Seguridad social integral', 'Verificar reglas vigentes de afiliación y cotización a salud, pensión y riesgos laborales.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Ley 1098 de 2006', 'Infancia y adolescencia', 'Verificar reglas vigentes cuando el trabajador sea adolescente o menor de edad.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar'),
('Ley 51 de 1983', 'Días festivos', 'Verificar festivos y reglas aplicables para el cálculo de términos en días hábiles.', 'https://www.funcionpublica.gov.co/eva/gestornormativo/', 'por_verificar')
ON DUPLICATE KEY UPDATE norma = VALUES(norma);

-- =====================================================================
-- ACTUALIZACIÓN AUTOMÁTICA DE TABLAS ANTIGUAS
-- Si la base de datos ya tenía tablas de una versión anterior (con login),
-- CREATE TABLE IF NOT EXISTS las deja como estaban y les faltarían columnas
-- (por ejemplo usuario.correo, usuario.intentos_fallidos o el rol 'supervisor').
-- Este bloque agrega SOLO lo que falta y no borra ni cambia datos existentes.
-- En una base nueva no hace nada. Se puede importar varias veces.
-- =====================================================================

-- usuario
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN correo VARCHAR(120) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'correo');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN telefono VARCHAR(20) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'telefono');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN cargo VARCHAR(100) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'cargo');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN intentos_fallidos TINYINT UNSIGNED NOT NULL DEFAULT 0', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'intentos_fallidos');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN bloqueado_hasta DATETIME NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'bloqueado_hasta');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN ultimo_acceso DATETIME NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'ultimo_acceso');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN politica_aceptada_en DATETIME NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'politica_aceptada_en');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE usuario ADD COLUMN politica_version VARCHAR(10) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'usuario' AND column_name = 'politica_version');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
ALTER TABLE usuario MODIFY rol ENUM('administrador','supervisor','usuario') NOT NULL DEFAULT 'usuario';

-- empresa
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE empresa ADD COLUMN clase_riesgo TINYINT UNSIGNED NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'empresa' AND column_name = 'clase_riesgo');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE empresa ADD COLUMN creado_por INT NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'empresa' AND column_name = 'creado_por');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE empresa ADD CONSTRAINT fk_empresa_usuario FOREIGN KEY (creado_por) REFERENCES usuario(id) ON DELETE SET NULL ON UPDATE CASCADE', 'DO 0') FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = 'empresa' AND constraint_name = 'fk_empresa_usuario');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- trabajador
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN autoriza_datos TINYINT(1) NOT NULL DEFAULT 0', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'autoriza_datos');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN autorizacion_fecha DATETIME NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'autorizacion_fecha');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN autorizacion_version VARCHAR(10) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'autorizacion_version');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN autorizacion_medio ENUM(''escrito'',''electronico'') NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'autorizacion_medio');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN autorizacion_registrada_por INT NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'autorizacion_registrada_por');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD COLUMN creado_por INT NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND column_name = 'creado_por');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD CONSTRAINT fk_trabajador_usuario FOREIGN KEY (creado_por) REFERENCES usuario(id) ON DELETE SET NULL ON UPDATE CASCADE', 'DO 0') FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND constraint_name = 'fk_trabajador_usuario');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE trabajador ADD CONSTRAINT fk_trabajador_autoriza FOREIGN KEY (autorizacion_registrada_por) REFERENCES usuario(id) ON DELETE SET NULL ON UPDATE CASCADE', 'DO 0') FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = 'trabajador' AND constraint_name = 'fk_trabajador_autoriza');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- contrato (los estados antiguos 'generado' y 'borrador' pasan a 'pendiente_revision')
ALTER TABLE contrato MODIFY estado ENUM('borrador','generado','pendiente_revision','aprobado','rechazado','anulado') NOT NULL DEFAULT 'pendiente_revision';
UPDATE contrato SET estado = 'pendiente_revision' WHERE estado IN ('generado','borrador');
ALTER TABLE contrato MODIFY estado ENUM('pendiente_revision','aprobado','rechazado','anulado') NOT NULL DEFAULT 'pendiente_revision';
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN labor_transitoria TINYINT(1) NOT NULL DEFAULT 1', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'labor_transitoria');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN fecha_firma DATE NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'fecha_firma');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN fecha_terminacion_estimada DATE NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'fecha_terminacion_estimada');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN puntaje_riesgo INT NOT NULL DEFAULT 0', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'puntaje_riesgo');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN nivel_riesgo ENUM(''bajo'',''medio'',''alto'') NOT NULL DEFAULT ''bajo''', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'nivel_riesgo');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN revisado_por INT NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'revisado_por');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN fecha_revision DATETIME NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'fecha_revision');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD COLUMN observacion_revision VARCHAR(500) NULL', 'DO 0') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'contrato' AND column_name = 'observacion_revision');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE contrato ADD CONSTRAINT fk_contrato_revisor FOREIGN KEY (revisado_por) REFERENCES usuario(id) ON DELETE SET NULL ON UPDATE CASCADE', 'DO 0') FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = 'contrato' AND constraint_name = 'fk_contrato_revisor');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
UPDATE contrato SET fecha_firma = DATE(fecha_registro) WHERE fecha_firma IS NULL;

-- empresa: la ciudad de Bogotá se escribe «Bogotá D.C.» (como en la lista desplegable)
UPDATE empresa SET ciudad = 'Bogotá D.C.' WHERE ciudad = 'Bogotá';

-- Comprobación posterior a la importación: SHOW TABLES;
-- Deben quedar 10 tablas: usuario, empresa, trabajador, contrato,
-- contrato_modificacion, contrato_riesgo, solicitud_datos, bitacora,
-- parametros_legales y norma_legal.
-- Este archivo se puede importar más de una vez sin errores (no borra datos).
