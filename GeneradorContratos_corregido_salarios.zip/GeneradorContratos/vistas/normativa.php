<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../datos/normaDAO.php";
require_once __DIR__ . "/_encabezado.php";
requerirLogin("login.php");
$normas = listarNormas($conexion);
encabezadoPagina("Normativa", "../");
?>
    <h2>Ley aplicable y fuentes consultadas</h2>
    <p>Marco legal que usa el sistema (<?= count($normas) ?> normas). Verifique siempre en la fuente oficial antes de
       decidir: la normativa laboral cambia.</p>
    <div class="tabla-scroll">
    <table class="tabla-listado">
        <thead><tr><th>Norma</th><th>Tema</th><th>Cómo se usa</th><th>Estado</th></tr></thead>
        <tbody>
        <?php foreach ($normas as $n) { ?>
            <tr>
                <td><strong><?= h($n["norma"]) ?></strong><?php if ($n["url"]) { ?><br><a href="<?= h($n["url"]) ?>" target="_blank" rel="noopener noreferrer">Fuente</a><?php } ?></td>
                <td><?= h($n["tema"]) ?></td>
                <td><?= h($n["aplicacion"]) ?></td>
                <td><?= $n["estado_verificacion"] === "verificada"
                        ? '<span class="insignia riesgo-bajo">Verificada</span>'
                        : '<span class="insignia riesgo-medio">Por verificar</span>' ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    </div>
    <div class="aviso-legal">
        Este sistema no sustituye la revisión de un abogado laboralista. «Por verificar» significa que la cita se
        incluyó de memoria del desarrollo y debe confirmarse en la fuente oficial.
    </div>
<?php piePagina("../"); ?>
