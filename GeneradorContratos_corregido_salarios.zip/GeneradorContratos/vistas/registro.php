<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../datos/usuarioDAO.php";
require_once __DIR__ . "/_encabezado.php";

if (estaAutenticado()) {
    header("Location: ../panel.php");
    exit();
}
if (!REGISTRO_PUBLICO && contarUsuarios($conexion) > 0) {
    $_SESSION["mensaje_login"] = "El registro público está desactivado. Pida su cuenta al administrador.";
    header("Location: login.php");
    exit();
}
[$d, $err] = recuperarFormulario("registro");

encabezadoPagina("Crear cuenta", "../", false, "acceso acceso-ancho");
?>
    <header class="encabezado">
        <h1>Crear cuenta</h1>
        <p class="subtitulo">La primera cuenta creada queda como administrador; las demás, como usuario.</p>
    </header>

    <form method="POST" action="../procesos/registrarUsuario.php" autocomplete="off">
        <?= campoCsrf() ?>
        <div class="campo">
            <label>Nombre completo *</label>
            <input type="text" name="nombre_completo" value="<?= val($d, 'nombre_completo') ?>" class="<?= claseError($err, 'nombre_completo') ?>">
            <?= errorCampo($err, "nombre_completo") ?>
        </div>
        <div class="campo-grupo">
            <div class="campo">
                <label>Usuario *</label>
                <input type="text" name="nombre_usuario" value="<?= val($d, 'nombre_usuario') ?>" maxlength="30" class="<?= claseError($err, 'nombre_usuario') ?>">
                <?= errorCampo($err, "nombre_usuario") ?>
            </div>
            <div class="campo">
                <label>Correo (opcional)</label>
                <input type="email" name="correo" value="<?= val($d, 'correo') ?>" class="<?= claseError($err, 'correo') ?>">
                <?= errorCampo($err, "correo") ?>
            </div>
        </div>
        <div class="campo-grupo">
            <div class="campo">
                <label>Contraseña *</label>
                <input type="password" name="clave" class="<?= claseError($err, 'clave') ?>">
                <small>Mínimo 10 caracteres con mayúsculas, minúsculas y números.</small>
                <?= errorCampo($err, "clave") ?>
            </div>
            <div class="campo">
                <label>Repetir contraseña *</label>
                <input type="password" name="clave2" class="<?= claseError($err, 'clave2') ?>">
                <?= errorCampo($err, "clave2") ?>
            </div>
        </div>
        <div class="campo campo-checkbox">
            <label>
                <input type="checkbox" name="acepta_politica" value="1">
                Acepto la <a href="politicaDatos.php" target="_blank">política de tratamiento de datos personales</a> *
            </label>
            <?= errorCampo($err, "politica") ?>
        </div>
        <button type="submit" class="btn-primario">Crear cuenta</button>
    </form>
    <p class="enlace-listado"><a href="login.php">Ya tengo cuenta</a></p>
<?php piePagina("../"); ?>
