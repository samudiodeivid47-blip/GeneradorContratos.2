<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../logica/calendario.php";
require_once __DIR__ . "/_encabezado.php";
requerirLogin("login.php");

// Mes pedido como ?mes=YYYY-MM (si no es válido, el mes actual).
$mesPedido = $_GET["mes"] ?? date("Y-m");
if (!preg_match('/^(\d{4})-(0[1-9]|1[0-2])$/', $mesPedido, $m) || (int) $m[1] < 2000 || (int) $m[1] > 2100) {
    $mesPedido = date("Y-m");
    preg_match('/^(\d{4})-(\d{2})$/', $mesPedido, $m);
}
$anio = (int) $m[1];
$mes = (int) $m[2];
$primero = new DateTimeImmutable(sprintf("%04d-%02d-01", $anio, $mes));
$anterior = $primero->modify("-1 month")->format("Y-m");
$siguiente = $primero->modify("+1 month")->format("Y-m");
$diasMes = (int) $primero->format("t");
$offset = (int) $primero->format("N") - 1;   // lunes = 0
$hoy = date("Y-m-d");

$eventos = eventosDelMes($conexion, $anio, $mes, (int) usuarioActual()["id"], puedeSupervisar());
$nombresMes = ["", "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

encabezadoPagina("Calendario", "../");
?>
    <h2>Calendario — <?= h(ucfirst($nombresMes[$mes]) . " " . $anio) ?></h2>
    <div class="barra-acciones">
        <a class="btn-secundario" href="?mes=<?= h($anterior) ?>">← Anterior</a>
        <a class="btn-secundario" href="?mes=<?= h(date("Y-m")) ?>">Hoy</a>
        <a class="btn-secundario" href="?mes=<?= h($siguiente) ?>">Siguiente →</a>
        <a class="btn-primario" href="../procesos/exportarCalendario.php">Exportar fechas (.ics)</a>
    </div>

    <div class="leyenda">
        <span class="insignia ev-firma">Firma</span><span class="insignia ev-inicio">Inicio</span>
        <span class="insignia ev-fin_prueba">Fin de prueba</span><span class="insignia ev-fin_estimado">Fin estimado</span>
        <span class="insignia ev-solicitud">Vence solicitud de datos</span><span class="insignia ev-festivo">Festivo</span>
        <span class="insignia ev-legal">Fecha legal</span>
    </div>

    <div class="calendario">
        <?php foreach (["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"] as $dn) { ?><div class="cal-cab"><?= $dn ?></div><?php } ?>
        <?php for ($i = 0; $i < $offset; $i++) { ?><div class="cal-dia cal-vacio"></div><?php } ?>
        <?php for ($dia = 1; $dia <= $diasMes; $dia++) {
            $fecha = sprintf("%04d-%02d-%02d", $anio, $mes, $dia);
            $dow = ($offset + $dia - 1) % 7;
            $clases = "cal-dia" . ($dow >= 5 ? " cal-finsemana" : "") . (isset($eventos[$fecha]) && in_array("festivo", array_column($eventos[$fecha], "tipo"), true) ? " cal-festivo" : "") . ($fecha === $hoy ? " cal-hoy" : "");
        ?>
            <div class="<?= $clases ?>">
                <span class="cal-num"><?= $dia ?></span>
                <?php foreach ($eventos[$fecha] ?? [] as $e) { ?>
                    <?php if ($e["enlace"]) { ?>
                        <a class="cal-evento ev-<?= h($e["tipo"]) ?>" href="<?= h($e["enlace"]) ?>" title="<?= h($e["detalle"]) ?>"><?= h($e["titulo"]) ?></a>
                    <?php } else { ?>
                        <span class="cal-evento ev-<?= h($e["tipo"]) ?>" title="<?= h($e["detalle"]) ?>"><?= h($e["titulo"]) ?></span>
                    <?php } ?>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

    <p class="nota-edicion">Los festivos se calculan con la Ley 51 de 1983 (Ley Emiliani) y las fechas legales son
        informativas. Verifique contra el calendario oficial. El período de prueba se cuenta con el día de inicio como día 1.</p>
<?php piePagina("../"); ?>
