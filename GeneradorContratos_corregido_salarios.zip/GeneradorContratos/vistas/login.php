<?php
require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/_encabezado.php";

if (estaAutenticado()) {
    header("Location: ../panel.php");
    exit();
}
$error = $_SESSION["error_login"] ?? "";
$mensaje = $_SESSION["mensaje_login"] ?? "";
$usuarioPrevio = $_SESSION["login_usuario"] ?? "";
unset($_SESSION["error_login"], $_SESSION["mensaje_login"], $_SESSION["login_usuario"]);

encabezadoPagina("Iniciar sesión", "../", false, "acceso");
?>
    <header class="encabezado">
        <h1>ContractPro</h1>
        <p class="subtitulo">Iniciar sesión</p>
    </header>

    <?php if ($mensaje !== "") { ?><div class="mensaje-ok"><?= h($mensaje) ?></div><?php } ?>
    <?php if ($error !== "") { ?><div class="mensaje-error-general"><?= h($error) ?></div><?php } ?>

    <form method="POST" action="../procesos/iniciarSesion.php" autocomplete="off">
        <?= campoCsrf() ?>
        <div class="campo">
            <label for="nombre_usuario">Usuario</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" value="<?= h($usuarioPrevio) ?>" maxlength="30" required>
        </div>
        <div class="campo">
            <label for="clave">Contraseña</label>
            <input type="password" id="clave" name="clave" required>
        </div>
        <button type="submit" class="btn-primario">Entrar</button>
    </form>

    <p class="enlace-listado">
        <?php if (REGISTRO_PUBLICO) { ?><a href="registro.php">Crear una cuenta</a> · <?php } ?>
        <a href="politicaDatos.php">Política de tratamiento de datos</a>
    </p>
<?php piePagina("../"); ?>
