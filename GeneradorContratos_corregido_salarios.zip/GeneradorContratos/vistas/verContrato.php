<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../logica/servicioContrato.php";
require_once __DIR__ . "/../datos/modificacionDAO.php";
require_once __DIR__ . "/../plantillas/contratoObraLabor.php";
require_once __DIR__ . "/_encabezado.php";
requerirLogin("login.php");

$id = idGet();
$contrato = $id ? buscarContratoPorId($conexion, $id) : null;
if (!$contrato || !puedeVerContrato($contrato)) {
    flash("error", "El contrato no existe o no tiene permiso para verlo.");
    header("Location: listado.php");
    exit();
}

$htmlContrato = generarTextoContrato($contrato);
$modificaciones = listarModificaciones($conexion, $id);
$riesgos = listarRiesgosContrato($conexion, $id);
$gravesAbiertos = contarGravesAbiertos($conexion, $id);
$residual = 0;
foreach ($riesgos as $r) {
    if ($r["estado"] === "abierto") {
        $residual += (int) $r["puntos"];
    }
}
$esMio = esPropietario($contrato, "usuario_id");
$puedeRevisar = puedeSupervisar() && !$esMio;

encabezadoPagina("Contrato #" . $id, "../");
?>
    <div class="barra-acciones no-imprimir">
        <a href="listado.php" class="btn-secundario">← Contratos</a>
        <button type="button" class="btn-primario" data-imprimir>Imprimir / Guardar PDF</button>
        <a href="autorizacionDatos.php?contrato=<?= $id ?>" class="btn-secundario">Autorización de datos (imprimir)</a>
        <?php if ($contrato["estado"] !== "anulado" && ($esMio || esAdministrador())) { ?>
            <a href="editarFunciones.php?id=<?= $id ?>" class="btn-secundario">Editar funciones</a>
        <?php } ?>
        <?php if (contratoEditable($contrato)) { ?>
            <a href="contratoForm.php?id=<?= $id ?>" class="btn-secundario">Corregir contrato</a>
        <?php } ?>
    </div>

    <div class="resumen-contrato no-imprimir">
        <p>Estado: <?= etiquetaEstado($contrato["estado"]) ?>
           · Riesgo: <?= etiquetaRiesgo($contrato["nivel_riesgo"], $contrato["puntaje_riesgo"]) ?>
           · Generado por <strong><?= h($contrato["autor_nombre"] ?? "—") ?></strong></p>
        <?php if ($contrato["revisor_nombre"]) { ?>
            <p>Revisado por <strong><?= h($contrato["revisor_nombre"]) ?></strong> el <?= h(fechaHoraCorta($contrato["fecha_revision"])) ?>
               <?= $contrato["observacion_revision"] ? "— «" . h($contrato["observacion_revision"]) . "»" : "" ?></p>
        <?php } ?>
        <p>Fechas: firma <strong><?= h(fechaCorta($contrato["fecha_firma"])) ?></strong>, inicio <strong><?= h(fechaCorta($contrato["fecha_inicio"])) ?></strong>,
           fin estimado <strong><?= h(fechaCorta($contrato["fecha_terminacion_estimada"])) ?></strong>.</p>
    </div>

    <?php /* ---------- Control de riesgo ---------- */ ?>
    <section id="riesgo" class="no-imprimir caja-datos">
        <h3>Control de riesgo</h3>
        <?php if (empty($riesgos)) { ?>
            <p>No se detectaron factores de riesgo.</p>
        <?php } else { ?>
            <p>Puntaje total <strong><?= (int) $contrato["puntaje_riesgo"] ?></strong>; riesgo residual (factores aún abiertos) <strong><?= $residual ?></strong>.
               Los factores graves (<?= RIESGO_PUNTOS_GRAVE ?> puntos o más) deben controlarse antes de aprobar.</p>
            <?php foreach ($riesgos as $r) { ?>
                <div class="factor <?= $r["puntos"] >= RIESGO_PUNTOS_GRAVE ? "factor-grave" : "" ?>">
                    <p><strong><?= h($r["codigo"]) ?></strong> · <?= (int) $r["puntos"] ?> pts
                        <span class="insignia factor-<?= h($r["estado"]) ?>"><?= h(ucfirst($r["estado"])) ?></span></p>
                    <p><?= h($r["descripcion"]) ?></p>
                    <p><em>Qué hacer:</em> <?= h($r["recomendacion"]) ?></p>
                    <?php if ($r["nota_control"]) { ?>
                        <p><em>Control:</em> <?= h($r["nota_control"]) ?> — <?= h($r["controlador"] ?? "") ?>, <?= h(fechaHoraCorta($r["fecha_control"])) ?></p>
                    <?php } ?>
                    <?php if ($puedeRevisar && $contrato["estado"] !== "anulado") { ?>
                        <form method="POST" action="../procesos/controlarRiesgo.php" class="form-control-riesgo">
                            <?= campoCsrf() ?>
                            <input type="hidden" name="accion" value="controlar">
                            <input type="hidden" name="contrato_id" value="<?= $id ?>">
                            <input type="hidden" name="factor_id" value="<?= (int) $r["id"] ?>">
                            <select name="estado">
                                <option value="mitigado">Mitigado (se corrigió)</option>
                                <option value="aceptado">Aceptado (se asume el riesgo)</option>
                                <option value="abierto">Reabrir</option>
                            </select>
                            <input type="text" name="nota" maxlength="300" placeholder="Nota: qué se hizo o por qué se acepta">
                            <button type="submit" class="btn-secundario">Guardar</button>
                        </form>
                    <?php } ?>
                </div>
            <?php } ?>
        <?php } ?>
        <?php if ($puedeRevisar && $contrato["estado"] !== "anulado") { ?>
            <form method="POST" action="../procesos/controlarRiesgo.php" class="form-en-linea">
                <?= campoCsrf() ?>
                <input type="hidden" name="accion" value="reevaluar">
                <input type="hidden" name="contrato_id" value="<?= $id ?>">
                <button type="submit" class="btn-secundario">Reevaluar riesgo con los datos actuales</button>
            </form>
        <?php } ?>
    </section>

    <?php /* ---------- Revisión del supervisor ---------- */ ?>
    <?php if (puedeSupervisar() && $contrato["estado"] !== "anulado") { ?>
    <section class="no-imprimir caja-datos">
        <h3>Revisión del supervisor</h3>
        <?php if ($esMio) { ?>
            <p>Usted generó este contrato: lo debe revisar otro supervisor o el administrador.</p>
        <?php } else { ?>
            <form method="POST" action="../procesos/revisarContrato.php" data-confirmar="¿Confirma la decisión?">
                <?= campoCsrf() ?>
                <input type="hidden" name="id" value="<?= $id ?>">
                <div class="campo">
                    <label>Observación (obligatoria para rechazar o anular)</label>
                    <textarea name="observacion" rows="2" maxlength="500"></textarea>
                </div>
                <?php if ($contrato["estado"] === "pendiente_revision") { ?>
                    <button type="submit" name="decision" value="aprobar" class="btn-generar">Aprobar</button>
                    <button type="submit" name="decision" value="rechazar" class="btn-secundario">Rechazar</button>
                <?php } ?>
                <button type="submit" name="decision" value="anular" class="btn-secundario">Anular contrato</button>
                <?php if ($gravesAbiertos > 0 && $contrato["estado"] === "pendiente_revision") { ?>
                    <p class="error-campo"><?= $gravesAbiertos ?> factor(es) grave(s) abierto(s): no se podrá aprobar hasta controlarlos.</p>
                <?php } ?>
            </form>
        <?php } ?>
    </section>
    <?php } ?>

    <div id="documentoContrato"><?= $htmlContrato ?></div>

    <div class="no-imprimir">
        <h3>Historial de modificaciones</h3>
        <?php if (empty($modificaciones)) { ?>
            <p>Este contrato no ha tenido modificaciones.</p>
        <?php } else { ?>
            <div class="tabla-scroll"><table class="tabla-listado">
                <thead><tr><th>Fecha</th><th>Campo</th><th>Anterior</th><th>Nuevo</th><th>Motivo</th><th>Usuario</th></tr></thead>
                <tbody>
                <?php foreach ($modificaciones as $m) { ?>
                    <tr>
                        <td><?= h(fechaHoraCorta($m["fecha_modificacion"])) ?></td>
                        <td><?= h($m["campo"]) ?></td>
                        <td><?= nl2br(h($m["valor_anterior"])) ?></td>
                        <td><?= nl2br(h($m["valor_nuevo"])) ?></td>
                        <td><?= h($m["motivo"]) ?></td>
                        <td><?= h($m["nombre_usuario"] ?? "") ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table></div>
        <?php } ?>
    </div>
<?php piePagina("../"); ?>
