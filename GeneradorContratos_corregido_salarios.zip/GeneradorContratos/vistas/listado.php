<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../datos/contratoDAO.php";
require_once __DIR__ . "/_encabezado.php";
requerirLogin("login.php");

$estado = $_GET["estado"] ?? "";
$nivel = $_GET["nivel"] ?? "";
$contratos = listarContratos($conexion, (int) usuarioActual()["id"], puedeSupervisar(), $estado, $nivel);
encabezadoPagina("Contratos", "../");
?>
    <h2>Contratos <?= puedeSupervisar() ? "(todos)" : "(los suyos)" ?></h2>
    <div class="barra-acciones">
        <a href="contratoForm.php" class="btn-primario">Nuevo contrato</a>
        <form method="GET" class="form-en-linea">
            <select name="estado" data-autoenviar>
                <option value="">Todos los estados</option>
                <?php foreach (["pendiente_revision" => "Pendiente de revisión", "aprobado" => "Aprobado", "rechazado" => "Rechazado", "anulado" => "Anulado"] as $k => $et) { ?>
                    <option value="<?= $k ?>" <?= seleccionado($estado, $k) ?>><?= $et ?></option>
                <?php } ?>
            </select>
            <select name="nivel" data-autoenviar>
                <option value="">Todo riesgo</option>
                <?php foreach (["alto", "medio", "bajo"] as $n) { ?>
                    <option value="<?= $n ?>" <?= seleccionado($nivel, $n) ?>>Riesgo <?= $n ?></option>
                <?php } ?>
            </select>
            <button type="submit" class="btn-secundario">Filtrar</button>
        </form>
    </div>
    <?php if (empty($contratos)) { ?>
        <p>No hay contratos con ese criterio.</p>
    <?php } else { ?>
    <div class="tabla-scroll"><table class="tabla-listado">
        <thead><tr><th>#</th><th>Trabajador</th><th>Empresa</th><th>Cargo</th><th>Inicio</th><th>Fin estimado</th><th>Estado</th><th>Riesgo</th><?php if (puedeSupervisar()) { ?><th>Autor</th><?php } ?><th></th></tr></thead>
        <tbody>
        <?php foreach ($contratos as $c) { ?>
            <tr>
                <td><?= (int) $c["id"] ?></td>
                <td><?= h($c["nombre_completo"]) ?></td>
                <td><?= h($c["razon_social"]) ?></td>
                <td><?= h($c["cargo"]) ?></td>
                <td><?= h(fechaCorta($c["fecha_inicio"])) ?></td>
                <td><?= h(fechaCorta($c["fecha_terminacion_estimada"])) ?></td>
                <td><?= etiquetaEstado($c["estado"]) ?></td>
                <td><?= etiquetaRiesgo($c["nivel_riesgo"], $c["puntaje_riesgo"]) ?>
                    <?= (int) $c["graves_abiertos"] > 0 ? '<span class="insignia riesgo-alto">' . (int) $c["graves_abiertos"] . ' grave(s) abierto(s)</span>' : "" ?></td>
                <?php if (puedeSupervisar()) { ?><td><?= h($c["generado_por"] ?? "—") ?></td><?php } ?>
                <td><a href="verContrato.php?id=<?= (int) $c["id"] ?>">Abrir</a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table></div>
    <?php } ?>
<?php piePagina("../"); ?>
