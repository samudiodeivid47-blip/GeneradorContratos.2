<?php
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../logica/sesion.php";
require_once __DIR__ . "/../logica/vista.php";
require_once __DIR__ . "/../datos/contratoDAO.php";
require_once __DIR__ . "/_encabezado.php";
requerirLogin("login.php");

$id = idGet();
$contrato = $id ? buscarContratoPorId($conexion, $id) : null;
if (!$contrato || $contrato["estado"] === "anulado" || !(esPropietario($contrato, "usuario_id") || esAdministrador())) {
    flash("error", "No tiene permiso para modificar las funciones de ese contrato.");
    header("Location: listado.php");
    exit();
}
[$dForm, $err] = recuperarFormulario("funciones");
$d = !empty($dForm) ? $dForm : ["funciones" => $contrato["funciones"], "motivo" => ""];

encabezadoPagina("Editar funciones", "../");
?>
    <div class="barra-acciones"><a href="verContrato.php?id=<?= $id ?>" class="btn-secundario">← Contrato #<?= $id ?></a></div>
    <h2>Editar funciones del contrato #<?= $id ?></h2>
    <p class="nota-edicion">Solo las funciones se pueden cambiar en un contrato generado. El cambio queda en el historial
        y, si el contrato estaba aprobado, vuelve a revisión del supervisor.</p>
    <form method="POST" action="../procesos/guardarFunciones.php" novalidate>
        <?= campoCsrf() ?>
        <input type="hidden" name="id" value="<?= $id ?>">
        <div class="campo">
            <label>Funciones *</label>
            <textarea name="funciones" rows="6" class="<?= claseError($err, 'funciones') ?>"><?= val($d, 'funciones') ?></textarea>
            <?= errorCampo($err, "funciones") ?>
        </div>
        <div class="campo">
            <label>Motivo del cambio *</label>
            <input type="text" name="motivo" maxlength="255" value="<?= val($d, 'motivo') ?>" class="<?= claseError($err, 'motivo') ?>">
            <?= errorCampo($err, "motivo") ?>
        </div>
        <button type="submit" class="btn-generar">Guardar cambio</button>
    </form>
<?php piePagina("../"); ?>
